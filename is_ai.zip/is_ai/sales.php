<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/header.php';

if (isset($_GET['success']) || isset($_GET['error'])) {
    echo '<div class="flash-message-container">';
    if (isset($_GET['success'])) {
        echo '<div class="alert alert-success flash-message">' . htmlspecialchars($_GET['success']) . '</div>';
    }
    if (isset($_GET['error'])) {
        echo '<div class="alert alert-danger flash-message">' . htmlspecialchars($_GET['error']) . '</div>';
    }
    echo '</div>';
}
?>

<head>
    <link rel="stylesheet" href="assets/css/styles.css"> <!-- Adjust path as needed -->
</head>

<div class="container-fluid">
    <div class="row">
        <?php require_once 'includes/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Sales Management</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newSaleModal">
                        <i class="bi bi-cart-plus"></i> New Sale
                    </button>
                </div>
            </div>

            <!-- Sales Table -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover" id="salesTable">
                            <thead>
                                <tr>
                                    <th>Sale ID</th>
                                    <th>Date</th>
                                    <th>Customer</th>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Unit Price</th>
                                    <th>Discount</th>
                                    <th>Total</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT s.*, c.fullName AS customerName, i.itemName 
                                          FROM sale s
                                          JOIN customer c ON s.customerID = c.customerID
                                          JOIN item i ON s.itemNumber = i.itemNumber
                                          ORDER BY s.saleDate DESC";
                                $result = $conn->query($query);

                                while ($row = $result->fetch_assoc()) {
                                    $total = $row['quantity'] * $row['unitPrice'] * (1 - $row['discount'] / 100);

                                    echo "<tr>
                                        <td>{$row['saleID']}</td>
                                        <td>" . date('M d, Y', strtotime($row['saleDate'])) . "</td>
                                        <td>{$row['customerName']}</td>
                                        <td>{$row['itemName']}</td>
                                        <td>{$row['quantity']}</td>
                                        <td>$" . number_format($row['unitPrice'], 2) . "</td>
                                        <td>{$row['discount']}%</td>
                                        <td>$" . number_format($total, 2) . "</td>
                                        <td>
                                            <button class='btn btn-sm btn-outline-info'>
                                                <i class='bi bi-receipt'></i> Invoice
                                            </button>
                                        </td>
                                    </tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Update the modal form in sales.php -->
<div class="modal fade" id="newSaleModal" tabindex="-1" aria-labelledby="newSaleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newSaleModalLabel">Record New Sale</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="saleForm" action="process_sale.php" method="POST">
                <div class="modal-body">
                    <div class="row g-3">
                        <!-- Customer Selection -->
                        <div class="col-md-6">
                            <label for="customer" class="form-label">Customer *</label>
                            <select class="form-select" id="customer" name="customerID" required>
                                <option value="">Select Customer</option>
                                <?php
                                $query = "SELECT customerID, fullName FROM customer WHERE status='Active'";
                                $result = $conn->query($query);
                                while ($row = $result->fetch_assoc()) {
                                    echo "<option value='{$row['customerID']}'>{$row['fullName']}</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <!-- Sale Date -->
                        <div class="col-md-6">
                            <label for="saleDate" class="form-label">Sale Date *</label>
                            <input type="date" class="form-control" id="saleDate" name="saleDate"
                                value="<?php echo date('Y-m-d'); ?>" required
                                min="<?php echo date('Y-m-d', strtotime('-1 year')); ?>"
                                max="<?php echo date('Y-m-d'); ?>">
                        </div>

                        <!-- Product Selection -->
                        <div class="col-md-6">
                            <label for="product" class="form-label">Product *</label>
                            <select class="form-select" id="product" name="itemNumber" required>
                                <option value="">Select Product</option>
                                <?php
                                $query = "SELECT itemNumber, itemName, stock, unitPrice FROM item WHERE status='Active' AND stock > 0";
                                $result = $conn->query($query);
                                while ($row = $result->fetch_assoc()) {
                                    echo "<option value='{$row['itemNumber']}' 
                                          data-price='{$row['unitPrice']}' 
                                          data-stock='{$row['stock']}'
                                          data-discount='{$row['discount']}'>
                                          {$row['itemName']} (Stock: {$row['stock']}, Price: {$row['unitPrice']})
                                          </option>";
                                }
                                ?>
                            </select>
                        </div>

                        <!-- Unit Price (auto-filled) -->
                        <div class="col-md-3">
                            <label for="unitPrice" class="form-label">Unit Price *</label>
                            <input type="number" step="0.01" class="form-control" id="unitPrice" name="unitPrice" readonly required>
                        </div>

                        <!-- Quantity -->
                        <div class="col-md-3">
                            <label for="quantity" class="form-label">Quantity *</label>
                            <input type="number" class="form-control" id="quantity" name="quantity"
                                min="1" value="1" required>
                            <small class="text-muted" id="stockMessage"></small>
                        </div>

                        <!-- Discount -->
                        <div class="col-md-6">
                            <label for="discount" class="form-label">Discount (%)</label>
                            <input type="number" step="0.1" class="form-control" id="discount"
                                name="discount" min="0" max="100" value="0">
                        </div>



                        <!-- Total Amount (auto-calculated) -->
                        <div class="col-md-6">
                            <label for="total" class="form-label">Total Amount</label>
                            <input type="text" class="form-control bg-light" id="total" readonly>
                            <input type="hidden" id="calculatedTotal" name="total">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" name="addSale">Record Sale</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize DataTable
        $('#salesTable').DataTable({
            responsive: true,
            order: [
                [1, 'desc']
            ]
        });

        // Form elements
        const productSelect = document.getElementById('product');
        const unitPriceInput = document.getElementById('unitPrice');
        const quantityInput = document.getElementById('quantity');
        const discountInput = document.getElementById('discount');
        const totalInput = document.getElementById('total');
        const calculatedTotal = document.getElementById('calculatedTotal');
        const stockMessage = document.getElementById('stockMessage');
        const saleForm = document.getElementById('saleForm');

        // Update form when product changes
        productSelect.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];

            if (selectedOption.value) {
                // Set unit price
                const price = selectedOption.dataset.price;
                unitPriceInput.value = price;

                // Set max quantity and show stock
                const stock = selectedOption.dataset.stock;
                quantityInput.setAttribute('max', stock);
                stockMessage.textContent = `Max available: ${stock}`;

                // Set default discount from product
                const productDiscount = selectedOption.dataset.discount || 0;
                discountInput.value = productDiscount;

                calculateTotal();
            } else {
                unitPriceInput.value = '';
                quantityInput.removeAttribute('max');
                stockMessage.textContent = '';
                discountInput.value = 0;
                totalInput.value = '';
            }
        });

        // Calculate total when values change
        [quantityInput, discountInput].forEach(input => {
            input.addEventListener('input', calculateTotal);
        });

        // Calculate the total amount
        function calculateTotal() {
            const quantity = parseFloat(quantityInput.value) || 0;
            const unitPrice = parseFloat(unitPriceInput.value) || 0;
            const discount = parseFloat(discountInput.value) || 0;

            const subtotal = quantity * unitPrice;
            const total = subtotal * (1 - discount / 100);

            totalInput.value = '$' + total.toFixed(2);
            calculatedTotal.value = total.toFixed(2);
        }

        // Form validation before submission
        saleForm.addEventListener('submit', function(e) {
            // Validate date format
            const saleDate = document.getElementById('saleDate').value;
            if (!saleDate || !/^\d{4}-\d{2}-\d{2}$/.test(saleDate)) {
                e.preventDefault();
                alert('Please select a valid date in YYYY-MM-DD format');
                return false;
            }

            // Validate quantity doesn't exceed stock
            const selectedProduct = productSelect.options[productSelect.selectedIndex];
            if (selectedProduct.value) {
                const maxQuantity = parseInt(selectedProduct.dataset.stock);
                const requestedQuantity = parseInt(quantityInput.value);

                if (requestedQuantity > maxQuantity) {
                    e.preventDefault();
                    alert(`Cannot sell more than available stock (${maxQuantity})`);
                    return false;
                }
            }

            return true;
        });
    });
</script>

<?php require_once 'includes/footer.php'; ?>