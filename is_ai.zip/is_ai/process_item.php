<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Add new item
if (isset($_POST['addItem'])) {
    $itemNumber = trim($_POST['itemNumber']);
    $itemName = trim($_POST['itemName']);
    $unitPrice = floatval($_POST['unitPrice']);
    $discount = floatval($_POST['discount']);
    $stock = intval($_POST['stock']);
    $description = trim($_POST['description']);
    $status = 'Active'; // Default status

    // Handle file upload
    $imageURL = 'imageNotAvailable.jpg';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $uploadDir = 'assets/img/';
        $fileExt = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $fileName = time() . '_' . uniqid() . '.' . $fileExt;
        $uploadFile = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadFile)) {
            $imageURL = $fileName;
        }
    }

    // Insert into database
    $query = "INSERT INTO item (itemNumber, itemName, discount, stock, unitPrice, imageURL, status, description) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssddssss', $itemNumber, $itemName, $discount, $stock, $unitPrice, $imageURL, $status, $description);

    if ($stmt->execute()) {
        header("Location: inventory.php?success=Item added successfully");
    } else {
        header("Location: inventory.php?error=Error adding item");
    }
    exit();
}

// Edit existing item
if (isset($_POST['editItem'])) {
    $productID = intval($_POST['productID']);
    $itemNumber = trim($_POST['itemNumber']);
    $itemName = trim($_POST['itemName']);
    $unitPrice = floatval($_POST['unitPrice']);
    $discount = floatval($_POST['discount']);
    $stock = intval($_POST['stock']);
    $description = trim($_POST['description']);
    $status = trim($_POST['status']);

    // Get current image
    $query = "SELECT imageURL FROM item WHERE productID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $productID);
    $stmt->execute();
    $result = $stmt->get_result();
    $currentImage = $result->fetch_assoc()['imageURL'];
    $imageURL = $currentImage;

    // Handle file upload if new image is provided
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $uploadDir = 'assets/img/';
        $fileExt = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $fileName = time() . '_' . uniqid() . '.' . $fileExt;
        $uploadFile = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadFile)) {
            // Delete old image if it's not the default
            if ($currentImage !== 'imageNotAvailable.jpg' && file_exists($uploadDir . $currentImage)) {
                unlink($uploadDir . $currentImage);
            }
            $imageURL = $fileName;
        }
    }
    // Generate new QR code if ID changed
    if(!file_exists("assets/qrcodes/{$_POST['productID']}.png")) {
        require 'phpqrcode/qrlib.php';
        $url = "https://yourdomain.com/edit_item_mobile.php?id=".$_POST['productID'];
        $file = "assets/qrcodes/{$_POST['productID']}.png";
        QRcode::png($url, $file, 'L', 10, 2);
        
        $stmt = $conn->prepare("UPDATE item SET qr_code = ? WHERE productID = ?");
        $stmt->bind_param("si", $file, $_POST['productID']);
        $stmt->execute();
    }

    // Update database
    $query = "UPDATE item SET 
              itemNumber = ?, 
              itemName = ?, 
              discount = ?, 
              stock = ?, 
              unitPrice = ?, 
              imageURL = ?, 
              status = ?, 
              description = ? 
              WHERE productID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssddssssi', $itemNumber, $itemName, $discount, $stock, $unitPrice, $imageURL, $status, $description, $productID);

    if ($stmt->execute()) {
        header("Location: inventory.php?success=Item updated successfully");
    } else {
        header("Location: inventory.php?error=Error updating item");
    }
    exit();
}

// Delete item
if (isset($_GET['delete'])) {
    $productID = intval($_GET['delete']);

    // First get the image to delete it from server
    $query = "SELECT imageURL FROM item WHERE productID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $productID);
    $stmt->execute();
    $result = $stmt->get_result();
    $imageURL = $result->fetch_assoc()['imageURL'];

    // Delete the item
    $query = "DELETE FROM item WHERE productID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $productID);

    if ($stmt->execute()) {
        // Delete the image if it's not the default
        if ($imageURL !== 'imageNotAvailable.jpg' && file_exists('assets/img/' . $imageURL)) {
            unlink('assets/img/' . $imageURL);
        }
        header("Location: inventory.php?success=Item deleted successfully");
    } else {
        header("Location: inventory.php?error=Error deleting item");
    }
    exit();
}

header("Location: inventory.php");
