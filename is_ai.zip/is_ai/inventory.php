<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/header.php';

if (isset($_GET['success']) || isset($_GET['error'])) {
    echo '<div class="flash-message-container">';
    if (isset($_GET['success'])) {
        echo '<div class="alert alert-success flash-message">' . htmlspecialchars($_GET['success']) . '</div>';
    }
    if (isset($_GET['error'])) {
        echo '<div class="alert alert-danger flash-message">' . htmlspecialchars($_GET['error']) . '</div>';
    }
    echo '</div>';
}
?>

<head>
    <link rel="stylesheet" href="assets/css/styles.css"> <!-- Adjust path as needed -->
</head>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'includes/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Inventory Management</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addItemModal">
                        <i class="bi bi-plus-circle"></i> Add New Item
                    </button>
                </div>
            </div>

            <!-- Filter Section -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-3">
                            <label for="search" class="form-label">Search</label>
                            <input type="text" class="form-control" id="search" name="search" placeholder="Product name or ID" value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="status" class="form-label">Status</label>
                            <select id="status" name="status" class="form-select">
                                <option value="">All</option>
                                <option value="Active" <?= (isset($_GET['status']) && $_GET['status'] == 'Active' ? 'selected' : '') ?>>Active</option>
                                <option value="Disabled" <?= (isset($_GET['status']) && $_GET['status'] == 'Disabled' ? 'selected' : '') ?>>Disabled</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="stock" class="form-label">Stock Level</label>
                            <select id="stock" name="stock" class="form-select">
                                <option value="">All</option>
                                <option value="low" <?= (isset($_GET['stock']) && $_GET['stock'] == 'low' ? 'selected' : '') ?>>Low (<5)< /option>
                                <option value="medium" <?= (isset($_GET['stock']) && $_GET['stock'] == 'medium' ? 'selected' : '') ?>>Medium (5-20)</option>
                                <option value="high" <?= (isset($_GET['stock']) && $_GET['stock'] == 'high' ? 'selected' : '') ?>>High (>20)</option>
                            </select>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">Filter</button>
                            <?php if (isset($_GET['search'])) { ?>
                                <a href="inventory.php" class="btn btn-outline-secondary ms-2">Clear</a>
                            <?php } ?>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Inventory Table -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover" id="inventoryTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Image</th>
                                    <th>Product Name</th>
                                    <th>Stock</th>
                                    <th>Price</th>
                                    <th>Discount</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                    <th>QR Code</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Build the query with filters
                                $query = "SELECT * FROM item WHERE 1=1";
                                $params = [];

                                if (isset($_GET['search']) && !empty($_GET['search'])) {
                                    $query .= " AND (itemName LIKE ? OR itemNumber LIKE ?)";
                                    $searchTerm = '%' . $_GET['search'] . '%';
                                    $params[] = $searchTerm;
                                    $params[] = $searchTerm;
                                }

                                if (isset($_GET['status']) && !empty($_GET['status'])) {
                                    $query .= " AND status = ?";
                                    $params[] = $_GET['status'];
                                }

                                if (isset($_GET['stock']) && !empty($_GET['stock'])) {
                                    switch ($_GET['stock']) {
                                        case 'low':
                                            $query .= " AND stock < 5";
                                            break;
                                        case 'medium':
                                            $query .= " AND stock BETWEEN 5 AND 20";
                                            break;
                                        case 'high':
                                            $query .= " AND stock > 20";
                                            break;
                                    }
                                }

                                $query .= " ORDER BY productID DESC";

                                $stmt = $conn->prepare($query);
                                if ($params) {
                                    $types = str_repeat('s', count($params));
                                    $stmt->bind_param($types, ...$params);
                                }
                                $stmt->execute();
                                $result = $stmt->get_result();

                                while ($row = $result->fetch_assoc()) {
                                    $statusBadge = ($row['status'] == 'Active') ?
                                        '<span class="badge bg-success">Active</span>' :
                                        '<span class="badge bg-secondary">Disabled</span>';

                                    $stockBadge = '';
                                    if ($row['stock'] < 5) {
                                        $stockBadge = '<span class="badge bg-danger">Low</span>';
                                    } elseif ($row['stock'] < 20) {
                                        $stockBadge = '<span class="badge bg-warning">Medium</span>';
                                    } else {
                                        $stockBadge = '<span class="badge bg-success">High</span>';
                                    }

                                    echo "<tr>
    <td>{$row['itemNumber']}</td>
    <td><img src='assets/img/{$row['imageURL']}' width='50' height='50' class='img-thumbnail'></td>
    <td>{$row['itemName']}</td>
    <td>{$row['stock']} {$stockBadge}</td>
    <td>$" . number_format($row['unitPrice'], 2) . "</td>
    <td>{$row['discount']}%</td>
    <td>{$statusBadge}</td>
    <td>
        <button class='btn btn-sm btn-outline-primary' data-bs-toggle='modal' data-bs-target='#editItemModal' data-id='{$row['productID']}'>
            <i class='bi bi-pencil'></i>
        </button>
        <button class='btn btn-sm btn-outline-danger' data-bs-toggle='modal' data-bs-target='#deleteItemModal' data-id='{$row['productID']}'>
            <i class='bi bi-trash'></i>
        </button>
        <a href='edit_item_mobile.php?id={$row['productID']}' class='btn btn-sm btn-outline-info'>
            <i class='bi bi-phone'></i>
        </a>
        
    </td>
    <td class='text-center'>
        <img src='generate_qr.php?id={$row['productID']}' width='80' height='80' class='img-thumbnail qr-code'>
    </td>
</tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Add Item Modal -->
<div class="modal fade" id="addItemModal" tabindex="-1" aria-labelledby="addItemModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class=" modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addItemModalLabel">Add New Inventory Item</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="process_item.php" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="itemNumber" class="form-label">Item Number</label>
                            <input type="text" class="form-control" id="itemNumber" name="itemNumber" required>
                        </div>
                        <div class="col-md-6">
                            <label for="itemName" class="form-label">Item Name</label>
                            <input type="text" class="form-control" id="itemName" name="itemName" required>
                        </div>
                        <div class="col-md-4">
                            <label for="unitPrice" class="form-label">Unit Price</label>
                            <input type="number" step="0.01" class="form-control" id="unitPrice" name="unitPrice" required>
                        </div>
                        <div class="col-md-4">
                            <label for="discount" class="form-label">Discount (%)</label>
                            <input type="number" step="0.1" class="form-control" id="discount" name="discount" value="0">
                        </div>
                        <div class="col-md-4">
                            <label for="stock" class="form-label">Initial Stock</label>
                            <input type="number" class="form-control" id="stock" name="stock" value="0" min="0">
                        </div>
                        <div class="col-md-12">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                        </div>
                        <div class="col-md-12">
                            <label for="image" class="form-label">Product Image</label>
                            <input class="form-control" type="file" id="image" name="image" accept="image/*">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" name="addItem">Save Item</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Item Modal -->
<div class="modal fade" id="editItemModal" tabindex="-1" aria-labelledby="editItemModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class=" modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editItemModalLabel">Edit Inventory Item</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="process_item.php" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" id="edit_productID" name="productID">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="edit_itemNumber" class="form-label">Item Number</label>
                            <input type="text" class="form-control" id="edit_itemNumber" name="itemNumber" required>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_itemName" class="form-label">Item Name</label>
                            <input type="text" class="form-control" id="edit_itemName" name="itemName" required>
                        </div>
                        <div class="col-md-4">
                            <label for="edit_unitPrice" class="form-label">Unit Price</label>
                            <input type="number" step="0.01" class="form-control" id="edit_unitPrice" name="unitPrice" required>
                        </div>
                        <div class="col-md-4">
                            <label for="edit_discount" class="form-label">Discount (%)</label>
                            <input type="number" step="0.1" class="form-control" id="edit_discount" name="discount" value="0">
                        </div>
                        <div class="col-md-4">
                            <label for="edit_stock" class="form-label">Stock</label>
                            <input type="number" class="form-control" id="edit_stock" name="stock" value="0" min="0">
                        </div>
                        <div class="col-md-12">
                            <label for="edit_description" class="form-label">Description</label>
                            <textarea class="form-control" id="edit_description" name="description" rows="3"></textarea>
                        </div>
                        <div class="col-md-12">
                            <label for="edit_image" class="form-label">Product Image</label>
                            <input class="form-control" type="file" id="edit_image" name="image" accept="image/*">
                            <div class="mt-2" id="currentImageContainer">
                                <small>Current Image:</small>
                                <img id="currentImage" src="" class="img-thumbnail mt-1" style="max-width: 100px;">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_status" class="form-label">Status</label>
                            <select class="form-select" id="edit_status" name="status">
                                <option value="Active">Active</option>
                                <option value="Disabled">Disabled</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" name="editItem">Update Item</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteItemModal" tabindex="-1" aria-labelledby="deleteItemModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class=" modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteItemModalLabel">Confirm Deletion</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this item? This action cannot be undone.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteButton">Delete</button>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // DataTable initialization
        $('#inventoryTable').DataTable({
            responsive: true
        });

        // Edit modal handling
        $('#editItemModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var productID = button.data('id');
            var modal = $(this);

            // Fetch item data via AJAX
            $.ajax({
                url: 'get_item.php',
                type: 'GET',
                data: {
                    id: productID
                },
                dataType: 'json',
                success: function(data) {
                    modal.find('#edit_productID').val(data.productID);
                    modal.find('#edit_itemNumber').val(data.itemNumber);
                    modal.find('#edit_itemName').val(data.itemName);
                    modal.find('#edit_unitPrice').val(data.unitPrice);
                    modal.find('#edit_discount').val(data.discount);
                    modal.find('#edit_stock').val(data.stock);
                    modal.find('#edit_description').val(data.description);
                    modal.find('#edit_status').val(data.status);

                    // Show current image if exists
                    if (data.imageURL && data.imageURL !== 'imageNotAvailable.jpg') {
                        modal.find('#currentImage').attr('src', 'assets/img/' + data.imageURL);
                        modal.find('#currentImageContainer').show();
                    } else {
                        modal.find('#currentImageContainer').hide();
                    }
                }
            });
        });

        // Delete modal handling
        var deleteProductId;
        $('#deleteItemModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            deleteProductId = button.data('id'); // Store the product ID to delete
        });


        // Confirm delete action
        document.getElementById('confirmDeleteButton').addEventListener('click', function() {
            window.location.href = 'process_item.php?delete=' + deleteProductId;
        });
        // Auto-dismiss flash messages
        setTimeout(function() {
            var flashMessage = document.getElementById('flash-message');
            if (flashMessage) {
                flashMessage.style.transition = 'opacity 1s ease-in-out';
                flashMessage.style.opacity = '0';
                setTimeout(function() {
                    flashMessage.remove();
                }, 1000);
            }
        }, 3000); // Message will disappear after 3 seconds

        // Center the modal messages if they appear
        $('.alert').addClass('text-center');
    });
</script>

<?php require_once 'includes/footer.php'; ?>