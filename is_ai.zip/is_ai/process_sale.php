<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['addSale'])) {
    $saleDate = $conn->real_escape_string($_POST['saleDate']);
    $customerID = intval($_POST['customerID']);
    $itemNumber = $conn->real_escape_string($_POST['itemNumber']);
    
    $quantity = intval($_POST['quantity']);
    $unitPrice = floatval($_POST['unitPrice']);
    $discount = floatval($_POST['discount']);
    
    // Retrieve customer name
    $customer_query = "SELECT fullName FROM customer WHERE customerID = $customerID";
    $customer_result = $conn->query($customer_query);
    $customer_row = $customer_result->fetch_assoc();
    $customerName = $customer_row['fullName'];

    // Retrieve item name
    $item_query = "SELECT itemName FROM item WHERE itemNumber = '$itemNumber'";
    $item_result = $conn->query($item_query);
    $item_row = $item_result->fetch_assoc();
    $itemName = $item_row['itemName'];

    // First check if we have enough stock
    $stock_check = "SELECT stock FROM item WHERE itemNumber = '$itemNumber'";
    $stock_result = $conn->query($stock_check);
    $stock_row = $stock_result->fetch_assoc();
    $current_stock = $stock_row['stock'];
    
    if ($current_stock < $quantity) {
        header("Location: sales.php?error=Not enough stock available");
        exit();
    }
    
    // Insert sale record
    $query = "INSERT INTO sale (saleDate, customerID, itemNumber, quantity, unitPrice, discount, customerName, itemName) 
              VALUES ('$saleDate', $customerID, '$itemNumber', $quantity, $unitPrice, $discount, '$customerName', '$itemName')";
    
    if ($conn->query($query)) {
        // Update item stock
        $update_stock = "UPDATE item SET stock = stock - $quantity WHERE itemNumber = '$itemNumber'";
        $conn->query($update_stock);
        
        header("Location: sales.php?success=Sale recorded successfully");
    } else {
        header("Location: sales.php?error=Error recording sale: " . $conn->error);
    }
    exit();
}

header("Location: sales.php");
?>