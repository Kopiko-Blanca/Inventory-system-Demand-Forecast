<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $query = "SELECT * FROM item WHERE productID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $item = $result->fetch_assoc();
        header('Content-Type: application/json');
        echo json_encode($item);
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'Item not found']);
    }
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid request']);
}
?>