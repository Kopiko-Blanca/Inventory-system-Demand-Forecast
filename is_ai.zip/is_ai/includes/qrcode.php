<?php
require_once 'phpqrcode/qrlib.php'; // You'll need to download the phpqrcode library