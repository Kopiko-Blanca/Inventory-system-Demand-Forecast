<?php $current_page = basename($_SERVER['PHP_SELF']); ?>
<div class="sidebar-wrapper">
    <!-- Hamburger Menu Button (Visible only on mobile) -->
  

    <!-- Sidebar Content -->
    <div class="sidebar bg-dark text-white" id="sidebar">
        <div class="sidebar-header d-flex justify-content-between align-items-center p-3">
            <h3 class="m-0">Inventory</h3>
            <button class="btn btn-sm btn-outline-light close-sidebar d-lg-none">
                <i class="bi bi-x"></i>
            </button>
        </div>

        <ul class="nav flex-column px-2">
            <li class="nav-item">
                <a class="nav-link <?= ($current_page == 'index.php') ? 'active' : '' ?>" href="index.php">
                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page == 'inventory.php') ? 'active' : '' ?>" href="inventory.php">
                    <i class="bi bi-box-seam me-2"></i> Inventory
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page == 'sales.php') ? 'active' : '' ?>" href="sales.php">
                    <i class="bi bi-cart-check me-2"></i> Sales
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page == 'purchases.php') ? 'active' : '' ?>" href="purchases.php">
                    <i class="bi bi-cart-plus me-2"></i> Purchases
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page == 'customers.php') ? 'active' : '' ?>" href="customers.php">
                    <i class="bi bi-people me-2"></i> Customers
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page == 'vendors.php') ? 'active' : '' ?>" href="vendors.php">
                    <i class="bi bi-shop me-2"></i> Vendors
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page == 'forecast.php') ? 'active' : '' ?>" href="forecast.php">
                    <i class="bi bi-graph-up me-2"></i> Demand Forecast
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page == 'reports.php') ? 'active' : '' ?>" href="reports.php">
                    <i class="bi bi-file-earmark-text me-2"></i> Reports
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php" style="color: red;">
                    <i class="bi bi-box-arrow-left"></i> Logout
                </a>
            </li>
        </ul>
        <div class="sidebar-footer p-3 mt-auto">
            <!-- User dropdown (same as before) -->
            <div class="dropdown">
                <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle"
                    id="userDropdown" data-bs-toggle="dropdown">
                    <i class="bi bi-person-circle me-2"></i>
                    <strong><?php echo $_SESSION['username'] ?? 'Admin'; ?></strong>
                </a>
                <ul class="dropdown-menu dropdown-menu-dark text-small shadow">
                    <li><a class="dropdown-item" href="#"><i class="bi bi-person me-2"></i> Profile</a></li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Overlay for mobile -->
    <div class="sidebar-overlay d-lg-none" id="sidebarOverlay"></div>
</div>