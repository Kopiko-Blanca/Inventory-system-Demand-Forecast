<?php
class AIForecast
{
    private $conn;

    public function __construct($dbConnection)
    {
        $this->conn = $dbConnection;
    }

    public function generateForecasts($force = false)
    {
        // Only check last generated date if not forcing
        if (!$force) {
            $lastGenerated = $this->conn->query("SELECT IFNULL(MAX(created_at), '2000-01-01') as last FROM ai_forecasts")->fetch_assoc();
            if (strtotime($lastGenerated['last']) >= strtotime('today')) {
                return false;
            }
        }

        $query = "SELECT itemNumber FROM item WHERE status='Active'";
        $result = $this->conn->query($query);

        while ($row = $result->fetch_assoc()) {
            $this->generateProductForecast($row['itemNumber']);
        }
        return true;
    }

    private function generateProductForecast($itemNumber)
    {
        // Get daily sales data for the last 180 days (6 months) for better trend analysis
        $historyQuery = "SELECT saleDate, SUM(quantity) as total 
                        FROM sale 
                        WHERE itemNumber = ? 
                        AND saleDate >= DATE_SUB(CURDATE(), INTERVAL 180 DAY)
                        GROUP BY saleDate
                        ORDER BY saleDate ASC";
        $stmt = $this->conn->prepare($historyQuery);
        $stmt->bind_param("s", $itemNumber);
        $stmt->execute();
        $historyResult = $stmt->get_result();
    
        $historical = [];
        while ($row = $historyResult->fetch_assoc()) {
            $historical[] = [
                'date' => $row['saleDate'],
                'quantity' => $row['total']
            ];
        }
    
        $predictions = [];
        $daysOfData = count($historical);
    
        if ($daysOfData >= 7) { // Need at least a week of data
            // Calculate moving averages with more emphasis on recent data
            $shortTermAvg = $this->calculateWeightedMovingAverage($historical, 7); // 7-day weighted average
            $longTermAvg = $this->calculateMovingAverage($historical, 30); // 30-day simple average
            
            // Calculate trend factor based on recent sales
            $trendFactor = $this->calculateTrendFactor($historical);
            
            // Generate forecasts for next 90 days (3 months)
            for ($i = 1; $i <= 90; $i++) {
                $forecastDate = date('Y-m-d', strtotime("+$i days"));
                $dayOfWeek = date('N', strtotime($forecastDate)); // 1-7 (Monday-Sunday)
                
                // Get same day of week sales from historical data (last 8 weeks)
                $dayOfWeekSales = array_filter($historical, function($sale) use ($dayOfWeek) {
                    return date('N', strtotime($sale['date'])) == $dayOfWeek && 
                           strtotime($sale['date']) >= strtotime('-8 weeks');
                });
                
                $dayOfWeekAvg = count($dayOfWeekSales) > 0 ? 
                    array_sum(array_column($dayOfWeekSales, 'quantity')) / count($dayOfWeekSales) : 
                    $shortTermAvg;
                
                // Blend short-term and long-term trends with day-of-week pattern and trend factor
                $basePrediction = ($shortTermAvg * 0.7) + ($longTermAvg * 0.3);
                $dayAdjustment = $dayOfWeekAvg / ($longTermAvg > 0 ? $longTermAvg : 1);
                
                // Apply trend factor (1.1 for 10% upward trend, 0.9 for 10% downward, etc.)
                $trendMultiplier = 1 + $trendFactor;
                $predicted = round($basePrediction * $dayAdjustment * $trendMultiplier);
                
                // Confidence calculation based on:
                // - Data quantity (more data = higher confidence)
                // - Data variance (less variance = higher confidence)
                // - Recent data availability (more recent = higher confidence)
                $variance = $this->calculateVariance($historical);
                $recencyFactor = $this->calculateRecencyFactor($historical);
                
                $confidence = min(1, max(0.5, 
                             0.6 + 
                    (min($daysOfData, 180) / 300) - // More data increases confidence
                    ($variance * 0.05) +            // Less variance increases confidence
                    ($recencyFactor * 0.2)));        // More recent data increases confidence
                
                // Safety stock calculation based on:
                // - Forecasted demand
                // - Confidence level (lower confidence = more safety stock)
                // - Lead time (assuming 7 days lead time)
                $leadTimeDays = 7;
                $safetyStock = round(($predicted * (1 - $confidence) * 0.5) * sqrt($leadTimeDays));
                $recommendedStock = $predicted + $safetyStock;
    
                // Select forecast reason based on factors
                $reasons = $this->getForecastReasons($trendFactor, $dayAdjustment, $confidence);
                $reason = $reasons[array_rand($reasons)];
    
                $predictions[] = [
                    'itemNumber' => $itemNumber,
                    'forecast_date' => $forecastDate,
                    'predicted_demand' => max(0, $predicted), // Ensure not negative
                    'recommended_stock' => max(0, $recommendedStock),
                    'confidence' => $confidence,
                    'forecast_reason' => $reason,
                    'created_at' => date('Y-m-d H:i:s')
                ];
            }
    
            $this->saveForecasts($itemNumber, $predictions);
        }
        return $predictions;
    }
    
    private function getForecastReasons($trendFactor, $dayAdjustment, $confidence) {
        $reasons = [];
        
        // Trend-based reasons
        if ($trendFactor > 0.1) {
            $reasons[] = "Historical trends indicate increased demand";
        } elseif ($trendFactor < -0.1) {
            $reasons[] = "Historical trends indicate decreased demand";
        } else {
            $reasons[] = "Historical trends indicate stable demand";
        }
        
        // Day-of-week pattern reasons
        if ($dayAdjustment > 1.2) {
            $reasons[] = "Day-of-week patterns suggest above average demand";
        } elseif ($dayAdjustment < 0.8) {
            $reasons[] = "Day-of-week patterns suggest below average demand";
        } else {
            $reasons[] = "Day-of-week patterns suggest typical demand";
        }
        
        // Confidence-based reasons
        if ($confidence > 0.8) {
            $reasons[] = "High confidence prediction based on consistent historical data";
        } elseif ($confidence > 0.6) {
            $reasons[] = "Moderate confidence prediction based on available data";
        } else {
            $reasons[] = "Low confidence prediction due to limited or variable data";
        }
        
        // Market analysis reasons
        $reasons[] = "Market analysis predicts stable demand";
        $reasons[] = "Seasonal patterns suggest typical demand";
        
        return $reasons;
    }
    
    // Helper method to calculate weighted moving average (more recent = higher weight)
    private function calculateWeightedMovingAverage($data, $windowSize)
    {
        $recent = array_slice($data, -$windowSize);
        $count = count($recent);
        
        if ($count == 0) return 0;
        
        $sum = 0;
        $weightSum = 0;
        
        // Apply linear weights (most recent has highest weight)
        for ($i = 0; $i < $count; $i++) {
            $weight = ($i + 1) / $count; // Normalized weight from 1/n to 1
            $sum += $recent[$i]['quantity'] * $weight;
            $weightSum += $weight;
        }
        
        return $sum / $weightSum;
    }
    
    // Helper method to calculate simple moving average
    private function calculateMovingAverage($data, $windowSize)
    {
        $sum = 0;
        $count = min(count($data), $windowSize);
        $recent = array_slice($data, -$count);
        
        foreach ($recent as $point) {
            $sum += $point['quantity'];
        }
        
        return $sum / max(1, $count);
    }
    
    // Helper method to calculate variance
    private function calculateVariance($data)
    {
        $values = array_column($data, 'quantity');
        if (count($values) < 2) return 0;
        
        $mean = array_sum($values) / count($values);
        
        $variance = 0.0;
        foreach ($values as $value) {
            $variance += pow($value - $mean, 2);
        }
        
        return $variance / count($values);
    }
    
    // Helper method to calculate recency factor (0-1)
    private function calculateRecencyFactor($data)
    {
        if (count($data) == 0) return 0;
        
        $now = time();
        $totalRecency = 0;
        $maxRecency = 0;
        
        foreach ($data as $point) {
            $daysOld = ($now - strtotime($point['date'])) / (60 * 60 * 24);
            $recency = max(0, 1 - ($daysOld / 180)); // Linear decay over 180 days
            $totalRecency += $recency;
            $maxRecency += 1;
        }
        
        return $totalRecency / max(1, $maxRecency);
    }

    private function saveForecasts($itemNumber, $forecasts)
    {
        $deleteQuery = "DELETE FROM ai_forecasts WHERE itemNumber = ?";
        $stmt = $this->conn->prepare($deleteQuery);
        $stmt->bind_param("s", $itemNumber);
        $stmt->execute();

        $insertQuery = "INSERT INTO ai_forecasts 
                       (itemNumber, forecast_date, predicted_demand, recommended_stock, confidence, forecast_reason, created_at) 
                       VALUES (?, ?, ?, ?, ?, ?, ?)";

        $stmt = $this->conn->prepare($insertQuery);

        foreach ($forecasts as $forecast) {
            $stmt->bind_param(
                "ssddsss",
                $forecast['itemNumber'],
                $forecast['forecast_date'],
                $forecast['predicted_demand'],
                $forecast['recommended_stock'],
                $forecast['confidence'],
                $forecast['forecast_reason'],
                $forecast['created_at']
            );
            $stmt->execute();
        }
    }

    public function getProductForecasts($itemNumber)
    {
        $query = "SELECT * FROM ai_forecasts 
                 WHERE itemNumber = ? 
                 AND forecast_date >= CURDATE()
                 ORDER BY forecast_date ASC";

        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("s", $itemNumber);
        $stmt->execute();
        $result = $stmt->get_result();

        $forecasts = [];
        while ($row = $result->fetch_assoc()) {
            $forecasts[] = $row;
        }
        return $forecasts;
    }

    public function calculateTrendFactor($historicalData)
    {
        if (count($historicalData) < 3) return 0;

        // Use exponential smoothing to give more weight to recent trends
        $alpha = 0.3; // Smoothing factor
        $trend = 0;
        
        // Calculate initial trend (first difference)
        $prevValue = $historicalData[0]['quantity'];
        $trend = ($historicalData[1]['quantity'] - $prevValue) / $prevValue;
        
        // Apply exponential smoothing to subsequent differences
        for ($i = 2; $i < count($historicalData); $i++) {
            $currentDiff = ($historicalData[$i]['quantity'] - $historicalData[$i-1]['quantity']) / 
                          max(1, $historicalData[$i-1]['quantity']);
            $trend = $alpha * $currentDiff + (1 - $alpha) * $trend;
        }
        
        return $trend;
    }
}