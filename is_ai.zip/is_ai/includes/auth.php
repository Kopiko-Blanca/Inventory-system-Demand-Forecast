<?php
session_start();

// Redirect to login page if not authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Optional: Check if user still exists in database
require_once 'config.php';

$query = "SELECT userID FROM user WHERE userID = ? AND status = 'Active'";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    // User no longer exists or is disabled
    session_destroy();
    header("Location: ../login.php");
    exit();
}
?>