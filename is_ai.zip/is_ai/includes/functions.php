<?php
if (!defined('MIN_FORECAST_CONFIDENCE')) {
    define('MIN_FORECAST_CONFIDENCE', 0.6); // 60% minimum confidence threshold
}

function forecastDemand($productID, $method = 'weighted_moving_average', $period = 30) {
    global $conn;

    // Validate input
    if (empty($productID)) {
        return [
            'forecast' => "Invalid product ID",
            'confidence' => 0,
            'method' => 'N/A',
            'safety_stock' => 0,
            'has_sufficient_data' => false,
            'is_valid' => false
        ];
    }

    // Get historical sales data (last 24 months)
    $query = "SELECT quantity, saleDate FROM sale 
              WHERE itemNumber = ? 
              ORDER BY saleDate ASC 
              LIMIT 24";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $productID);
    $stmt->execute();
    $result = $stmt->get_result();

    $salesData = [];
    $monthlyTotals = array_fill(0, 12, 0);
    $monthlyCounts = array_fill(0, 12, 0);
    $totalSales = 0;
    $dataPoints = 0;

    while ($row = $result->fetch_assoc()) {
        $month = date('n', strtotime($row['saleDate'])) - 1;
        $monthlyTotals[$month] += (int)$row['quantity'];
        $monthlyCounts[$month]++;
        $totalSales += $row['quantity'];
        $dataPoints++;
        $salesData[] = [
            'date' => $row['saleDate'],
            'quantity' => (int)$row['quantity']
        ];
    }

    // Check if we have sufficient data
    if ($dataPoints < 6) {
        return [
            'forecast' => "Not enough data",
            'confidence' => 0,
            'method' => 'N/A',
            'safety_stock' => 0,
            'has_sufficient_data' => false,
            'is_valid' => false
        ];
    }

    // Calculate monthly averages
    $monthlyAverages = [];
    for ($i = 0; $i < 12; $i++) {
        $monthlyAverages[$i] = $monthlyCounts[$i] > 0 ? $monthlyTotals[$i] / $monthlyCounts[$i] : 0;
    }

    // Enhanced confidence calculation
    $dataQuality = min(1, $dataPoints / 24); // 0-1 based on data points
    $recencyFactor = min(1, count(array_filter(array_slice($monthlyCounts, -3))) / 3); // Recent months with data
    $averageMonthlySales = array_sum($monthlyTotals) / max(1, count(array_filter($monthlyTotals)));
    $varianceFactor = 1 - min(1, stats_standard_deviation($monthlyTotals) / max(1, $averageMonthlySales));
    $trendFactor = calculateTrendFactor($salesData);

    // Calculate forecast based on selected method
    switch ($method) {
        case 'simple_moving_average':
            $forecast = array_sum($monthlyTotals) / count(array_filter($monthlyCounts));
            $confidence = (0.5 + ($recencyFactor * 0.3) + ($varianceFactor * 0.2)) * $dataQuality;
            break;

        case 'weighted_moving_average':
            // Use weights that emphasize more recent data (last 3 months)
            $weights = [0.5, 0.3, 0.2];
            $weightedSum = 0;
            $validMonths = 0;
            $recentMonths = array_slice($monthlyTotals, -3, 3, true);
            $recentCounts = array_slice($monthlyCounts, -3, 3, true);

            foreach ($recentMonths as $i => $total) {
                if ($recentCounts[$i] > 0) {
                    $weight = $weights[$i] ?? 0.1;
                    $weightedSum += ($total / $recentCounts[$i]) * $weight;
                    $validMonths += $weight;
                }
            }

            $forecast = $validMonths > 0 ? $weightedSum / $validMonths : 0;
            $confidence = (0.6 + ($recencyFactor * 0.3) + ($trendFactor * 0.1)) * $dataQuality;
            break;

        case 'seasonal_adjusted':
            $yearlyAverage = array_sum($monthlyAverages) / 12;
            $seasonalIndices = [];

            foreach ($monthlyAverages as $avg) {
                $seasonalIndices[] = $yearlyAverage > 0 ? $avg / $yearlyAverage : 1;
            }

            $currentMonth = date('n') - 1;
            $nextMonth = ($currentMonth + 1) % 12;
            $forecast = $monthlyAverages[$currentMonth] * $seasonalIndices[$nextMonth];

            $fullYearData = (count(array_filter($monthlyCounts)) >= 12) ? 1 : 0.5;
            $confidence = (0.7 + ($fullYearData * 0.2) + ($trendFactor * 0.1)) * $dataQuality;
            break;

        default:
            $forecast = 0;
            $confidence = 0;
    }

    // Apply trend-based adjustment (only if trend is significant)
    if (abs($trendFactor) > 0.1) {
        $forecast = $forecast * (1 + ($trendFactor * 0.2));
    }

    // Enhanced safety stock calculation
    $leadTimeDays = 7; // Default lead time
    $dailyDemand = max(0.1, $forecast / 30); // Ensure minimum demand
    $demandVariability = stats_standard_deviation($monthlyTotals) / max(1, $averageMonthlySales);
    $serviceLevelFactor = 1.28; // Corresponds to ~90% service level

    // Safety stock formula: accounts for demand variability and lead time
    $safetyStock = round($dailyDemand * $leadTimeDays * $serviceLevelFactor * (1 + $demandVariability));

    // Adjust forecast based on period and add safety stock
    $adjustedForecast = (int)round(max(0, $forecast) * ($period / 30) + $safetyStock);

    return [
        'forecast' => $adjustedForecast,
        'confidence' => min(1, max(0, $confidence)), // Ensure 0-1 range
        'method' => ucfirst(str_replace('_', ' ', $method)),
        'safety_stock' => $safetyStock,
        'trend_factor' => $trendFactor,
        'has_sufficient_data' => true,
        'is_valid' => ($confidence >= MIN_FORECAST_CONFIDENCE)
    ];
}

function calculateTrendFactor($salesData) {
    if (count($salesData) < 3) return 0;

    // Calculate linear regression to determine trend
    $x = [];
    $y = [];
    $dates = [];
    
    foreach ($salesData as $i => $sale) {
        $x[] = $i; // Using index as x value (time)
        $y[] = $sale['quantity'];
        $dates[] = strtotime($sale['date']);
    }

    // Calculate linear regression coefficients
    $n = count($x);
    $sumX = array_sum($x);
    $sumY = array_sum($y);
    $sumXY = 0;
    $sumX2 = 0;

    for ($i = 0; $i < $n; $i++) {
        $sumXY += $x[$i] * $y[$i];
        $sumX2 += $x[$i] * $x[$i];
    }

    $slope = ($n * $sumXY - $sumX * $sumY) / ($n * $sumX2 - $sumX * $sumX);

    // Normalize the slope to a percentage of average sales
    $averageSales = $sumY / $n;
    $trendFactor = $averageSales > 0 ? $slope / $averageSales : 0;

    return $trendFactor;
}

function stats_standard_deviation(array $a, $sample = false) {
    $n = count($a);
    if ($n === 0) {
        return 0.0;
    }
    $mean = array_sum($a) / $n;
    $carry = 0.0;
    foreach ($a as $val) {
        $d = ((float) $val) - $mean;
        $carry += $d * $d;
    }
    if ($sample) {
        $n--;
    }
    return $n > 0 ? sqrt($carry / $n) : 0.0;
}



function getItemPrice($itemNumber) {
    global $conn;
    $itemNumber = $conn->real_escape_string($itemNumber);
    $query = "SELECT unitPrice FROM item WHERE itemNumber = '$itemNumber' LIMIT 1";
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['unitPrice'];
    }
    return 0.00;
}

function getPreferredVendor($itemNumber) {
    global $conn;
    $itemNumber = $conn->real_escape_string($itemNumber);

    $query = "SELECT vendorID FROM purchase 
              WHERE itemNumber = '$itemNumber' 
              GROUP BY vendorID 
              ORDER BY COUNT(*) DESC 
              LIMIT 1";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        return $result->fetch_assoc()['vendorID'];
    }

    $query = "SELECT vendorID FROM vendor WHERE status='Active' LIMIT 1";
    $result = $conn->query($query);
    return $result->fetch_assoc()['vendorID'];
}
function getInventoryStatusSummary() {
    global $conn;
    
    $statusCounts = [
        'sufficient' => 0,
        'needsReorder' => 0,
        'urgentReorder' => 0,
        'insufficientData' => 0
    ];
    
    $query = "SELECT itemNumber, stock FROM item WHERE status='Active'";
    $result = $conn->query($query);
    
    while ($row = $result->fetch_assoc()) {
        $forecastData = forecastDemand($row['itemNumber'], 'ai_forecast', 30);
        
        if (empty($forecastData) || !isset($forecastData['has_sufficient_data'])) {
            $statusCounts['insufficientData']++;
            continue;
        }
        
        $currentStock = (int)$row['stock'];
        $forecastValue = is_numeric($forecastData['forecast']) ? (int)$forecastData['forecast'] : 0;
        $safetyStock = isset($forecastData['safety_stock']) ? (int)$forecastData['safety_stock'] : 0;
        
        if ($currentStock >= ($forecastValue + $safetyStock)) {
            $statusCounts['sufficient']++;
        } else {
            $needed = max(0, $forecastValue - $currentStock);
            $suggestedOrder = max($needed, $safetyStock);
            
            if ($suggestedOrder > ($currentStock * 0.5)) {
                $statusCounts['urgentReorder']++;
            } else {
                $statusCounts['needsReorder']++;
            }
        }
    }
    
    return [
        $statusCounts['sufficient'],
        $statusCounts['needsReorder'],
        $statusCounts['urgentReorder'],
        $statusCounts['insufficientData']
    ];
}