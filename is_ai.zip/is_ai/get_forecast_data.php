<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once 'includes/ai_forecast.php';

// Set JSON header
header('Content-Type: application/json');

// Check required parameters
if (!isset($_GET['item'])) {
    http_response_code(400);
    die(json_encode(['error' => 'Item number not specified']));
}

// Get parameters
$itemNumber = $conn->real_escape_string($_GET['item']);
$method = isset($_GET['method']) ? $_GET['method'] : 'weighted_moving_average';
$period = isset($_GET['period']) ? (int)$_GET['period'] : 30;
$confidenceThreshold = isset($_GET['confidence']) ? (float)$_GET['confidence'] : MIN_FORECAST_CONFIDENCE;

// Validate method
$validMethods = ['weighted_moving_average', 'simple_moving_average', 'seasonal_adjusted', 'ai_forecast'];
if (!in_array($method, $validMethods)) {
    http_response_code(400);
    die(json_encode(['error' => 'Invalid forecasting method']));
}

// Get product name
$productQuery = "SELECT itemName FROM item WHERE itemNumber = ?";
$stmt = $conn->prepare($productQuery);
$stmt->bind_param("s", $itemNumber);
$stmt->execute();
$productResult = $stmt->get_result();

if ($productResult->num_rows === 0) {
    http_response_code(404);
    die(json_encode(['error' => 'Product not found']));
}

$productName = $productResult->fetch_assoc()['itemName'];

// Get historical sales data
$historyQuery = "SELECT quantity, saleDate FROM sale 
                WHERE itemNumber = ? 
                AND saleDate >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
                ORDER BY saleDate ASC";
$stmt = $conn->prepare($historyQuery);
$stmt->bind_param("s", $itemNumber);
$stmt->execute();
$historyResult = $stmt->get_result();

$historical = [];
while ($row = $historyResult->fetch_assoc()) {
    $historical[] = [
        'date' => $row['saleDate'],
        'quantity' => (int)$row['quantity']
    ];
}

// Get current stock level
$stockQuery = "SELECT stock FROM item WHERE itemNumber = ?";
$stmt = $conn->prepare($stockQuery);
$stmt->bind_param("s", $itemNumber);
$stmt->execute();
$stockResult = $stmt->get_result();
$currentStock = $stockResult->fetch_assoc()['stock'];

// Prepare forecast data based on method
if ($method === 'ai_forecast') {
    $aiForecast = new AIForecast($conn);
    $forecasts = $aiForecast->getProductForecasts($itemNumber);
    
    if (empty($forecasts)) {
        $currentForecast = [
            'forecast' => "No AI forecast available",
            'confidence' => 0,
            'safety_stock' => 0,
            'method' => 'AI Forecast',
            'forecast_reason' => 'Insufficient historical data for AI prediction',
            'has_sufficient_data' => false,
            'is_valid' => false
        ];
    } else {
        // Get the most recent forecast for the requested period
        $filteredForecasts = array_filter($forecasts, function($f) use ($period) {
            return strtotime($f['forecast_date']) <= strtotime("+$period days");
        });
        
        if (empty($filteredForecasts)) {
            $currentForecast = end($forecasts);
        } else {
            $currentForecast = reset($filteredForecasts);
        }
        
        $safetyStock = max(0, $currentForecast['recommended_stock'] - $currentForecast['predicted_demand']);
        
        $currentForecast = [
            'forecast' => (int)$currentForecast['predicted_demand'],
            'confidence' => (float)$currentForecast['confidence'],
            'safety_stock' => (int)$safetyStock,
            'method' => 'AI Forecast',
            'forecast_reason' => $currentForecast['forecast_reason'] ?? 'AI-generated prediction',
            'has_sufficient_data' => true,
            'is_valid' => $currentForecast['confidence'] >= $confidenceThreshold,
            'trend_factor' => $this->calculateTrendFactor($historical)
        ];
    }
} else {
    // Traditional forecasting methods
    $currentForecast = forecastDemand($itemNumber, $method, $period);
    
    // Enhance with additional data
    $currentForecast['method'] = ucfirst(str_replace('_', ' ', $method));
    $currentForecast['forecast_reason'] = 'Calculated using ' . $currentForecast['method'];
    $currentForecast['is_valid'] = $currentForecast['confidence'] >= $confidenceThreshold;
    
    // Calculate safety stock if not provided
    if (!isset($currentForecast['safety_stock'])) {
        $currentForecast['safety_stock'] = ceil($currentForecast['forecast'] * 0.2); // 20% of forecast
    }
}

// Prepare forecast projections for chart
$forecastProjections = [];
if ($currentForecast['has_sufficient_data'] && $currentForecast['is_valid']) {
    $lastHistoricalDate = new DateTime(end($historical)['date']);
    
    for ($i = 1; $i <= 3; $i++) { // Project 3 periods ahead
        $projectionDate = clone $lastHistoricalDate;
        $projectionDate->add(new DateInterval("P{$i}M")); // Add months
        
        // For AI forecasts, try to get specific projections
        if ($method === 'ai_forecast') {
            $projectionFound = false;
            foreach ($forecasts as $f) {
                if (date('Y-m', strtotime($f['forecast_date'])) === $projectionDate->format('Y-m')) {
                    $forecastProjections[] = [
                        'date' => $projectionDate->format('Y-m-d'),
                        'forecast' => (int)$f['predicted_demand'],
                        'safety_stock' => max(0, $f['recommended_stock'] - $f['predicted_demand'])
                    ];
                    $projectionFound = true;
                    break;
                }
            }
            
            if (!$projectionFound) {
                // If no specific projection, use the current forecast with slight variation
                $variation = 1 + (($i % 2 === 0) ? 0.1 : -0.1); // Alternate between +10% and -10%
                $forecastProjections[] = [
                    'date' => $projectionDate->format('Y-m-d'),
                    'forecast' => (int)($currentForecast['forecast'] * $variation),
                    'safety_stock' => (int)($currentForecast['safety_stock'] * $variation)
                ];
            }
        } else {
            // For traditional methods, project with slight variation
            $variation = 1 + (($i % 2 === 0) ? 0.1 : -0.1); // Alternate between +10% and -10%
            $forecastProjections[] = [
                'date' => $projectionDate->format('Y-m-d'),
                'forecast' => (int)($currentForecast['forecast'] * $variation),
                'safety_stock' => (int)($currentForecast['safety_stock'] * $variation)
            ];
        }
    }
}

// Prepare response
$response = [
    'historical' => $historical,
    'current_forecast' => $currentForecast,
    'forecast_projections' => $forecastProjections,
    'product_info' => [
        'itemNumber' => $itemNumber,
        'itemName' => $productName,
        'current_stock' => (int)$currentStock
    ],
    'metadata' => [
        'forecast_method' => $method,
        'forecast_period' => $period,
        'confidence_threshold' => $confidenceThreshold,
        'generated_at' => date('Y-m-d H:i:s')
    ]
];

echo json_encode($response);

/**
 * Helper function to calculate trend factor from historical data
 */
function calculateTrendFactor($historicalData) {
    if (count($historicalData) < 3) {
        return 0;
    }
    
    $lastThree = array_slice($historicalData, -3);
    $sum = 0;
    
    for ($i = 1; $i < count($lastThree); $i++) {
        $change = $lastThree[$i]['quantity'] - $lastThree[$i-1]['quantity'];
        $sum += $change;
    }
    
    $averageChange = $sum / (count($lastThree) - 1);
    $lastQuantity = $lastThree[count($lastThree)-1]['quantity'];
    
    return $lastQuantity > 0 ? ($averageChange / $lastQuantity) : 0;
}