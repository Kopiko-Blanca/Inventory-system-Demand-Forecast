<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require_once 'includes/header.php';
?>

<head>
    <link rel="stylesheet" href="assets/css/styles.css"> <!-- Adjust path as needed -->
</head>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <?php require_once 'includes/sidebar.php'; ?>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Dashboard</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
                    </div>
                </div>
            </div>

            <!-- Dashboard Cards -->
            <div class="row row-cols-1 row-cols-md-4 g-4 mb-4">
                <!-- Total Products Card -->
                <div class="col">
                    <div class="card text-white bg-primary h-100">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">Total Products</h5>
                            <div class="mt-auto">
                                <?php
                                $result = $conn->query("SELECT COUNT(*) FROM item WHERE status='Active'");
                                $row = $result->fetch_row();
                                echo "<h2 class='card-text'>" . $row[0] . "</h2>";
                                ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Total Sales Card -->
                <div class="col">
                    <div class="card text-white bg-success h-100">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">Total Sales</h5>
                            <div class="mt-auto">
                                <?php
                                $result = $conn->query("SELECT SUM(quantity * unitPrice) FROM sale");
                                $row = $result->fetch_row();
                                echo "<h2 class='card-text'>$" . number_format($row[0] ?? 0, 2) . "</h2>";
                                ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Active Customers Card -->
                <div class="col">
                    <div class="card text-white bg-info h-100">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">Active Customers</h5>
                            <div class="mt-auto">
                                <?php
                                $result = $conn->query("SELECT COUNT(*) FROM customer WHERE status='Active'");
                                $row = $result->fetch_row();
                                echo "<h2 class='card-text'>" . $row[0] . "</h2>";
                                ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Low Stock Items Card -->
                <div class="col">
                    <div class="card text-white bg-warning h-100">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">Low Stock Items</h5>
                            <div class="mt-auto">
                                <?php
                                $result = $conn->query("SELECT COUNT(*) FROM item WHERE stock < 5 AND status='Active'");
                                $row = $result->fetch_row();
                                echo "<h2 class='card-text'>" . $row[0] . "</h2>";
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Second Row of Dashboard Cards -->
            <div class="row row-cols-1 row-cols-md-4 g-4 mb-4">
                <!-- Forecast Accuracy Card (this will determine the height) -->
                <div class="col">
                    <div class="card text-white bg-secondary h-100">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">Forecast Accuracy</h5>
                            <div class="mt-auto">
                                <?php
                                $result = $conn->query("SELECT 
                        AVG(confidence)*100 as avg_confidence,
                        COUNT(DISTINCT itemNumber) as item_count
                        FROM ai_forecasts 
                        WHERE forecast_date >= CURDATE()");
                                $row = $result->fetch_assoc();
                                $avgConfidence = $row['avg_confidence'] ?? 0;
                                $itemCount = $row['item_count'] ?? 0;
                                echo "<h2 class='card-text'>" . number_format($avgConfidence, 1) . "%</h2>";
                                ?>
                                <p class="card-text small mb-2">
                                    <?= $itemCount ?> products with AI forecasts<br>
                                    Updated: <?= date('M j, g:i a') ?>
                                </p>
                                <div class="card-footer bg-transparent border-top-0 px-0 pb-0 pt-2">
                                    <a href="forecast.php" class="btn btn-sm btn-outline-light">View Details</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Reliable Forecasts Card -->
                <div class="col">
                    <div class="card text-white bg-dark h-100">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">Reliable Forecasts</h5>
                            <div class="mt-auto">
                                <?php
                                $result = $conn->query("SELECT itemNumber FROM item WHERE status='Active'");
                                $reliableForecasts = 0;
                                $totalItems = 0;
                                while ($row = $result->fetch_assoc()) {
                                    $forecastData = forecastDemand($row['itemNumber']);
                                    if ($forecastData['confidence'] > 0.8) {
                                        $reliableForecasts++;
                                    }
                                    $totalItems++;
                                }
                                echo "<h2 class='card-text'>$reliableForecasts/$totalItems</h2>";
                                ?>
                                <p class="card-text small">Items with >80% confidence</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Forecasted Demand Card -->
                <div class="col">
                    <div class="card text-white bg-info h-100">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">Forecasted Demand</h5>
                            <div class="mt-auto">
                                <?php
                                $totalForecast = 0;
                                $result = $conn->query("SELECT itemNumber, stock FROM item WHERE status='Active'");
                                while ($row = $result->fetch_assoc()) {
                                    $forecastData = forecastDemand($row['itemNumber']);
                                    if (is_numeric($forecastData['forecast'])) {
                                        $totalForecast += $forecastData['forecast'];
                                    }
                                }
                                echo "<h2 class='card-text'>" . number_format($totalForecast) . "</h2>";
                                ?>
                                <p class="card-text small">Total forecasted demand for all products</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Suggested Orders Card -->
                <div class="col">
                    <div class="card text-white bg-warning h-100">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">Suggested Orders</h5>
                            <div class="mt-auto">
                                <?php
                                $totalSuggested = 0;
                                $result = $conn->query("SELECT itemNumber, stock FROM item WHERE status='Active'");
                                while ($row = $result->fetch_assoc()) {
                                    $forecastData = forecastDemand($row['itemNumber']);
                                    $currentStock = max(0, (int)$row['stock']);
                                    $forecastValue = is_numeric($forecastData['forecast']) ? (int)$forecastData['forecast'] : 0;
                                    $safetyStock = (int)$forecastData['safety_stock'];
                                    $suggestedOrder = 0;
                                    if ($forecastValue > 0 && $forecastData['forecast'] !== "Not enough data") {
                                        $needed = max(0, $forecastValue - $currentStock);
                                        $suggestedOrder = max($needed, $safetyStock);
                                        if ($currentStock >= ($forecastValue + $safetyStock)) {
                                            $suggestedOrder = 0;
                                        }
                                    }
                                    $totalSuggested += $suggestedOrder;
                                }
                                echo "<h2 class='card-text'>" . number_format($totalSuggested) . "</h2>";
                                ?>
                                <p class="card-text small">Total suggested order quantity</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Add this after the dashboard cards section -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card mb-4">
                        <div class="card-header bg-info text-white">
                            <i class="fas fa-bolt me-2"></i> AI Forecast Highlights
                            <span class="float-end small">Next 30 Days</span>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <?php
                                $highlightSql = "SELECT i.itemNumber, i.itemName, 
                        f.predicted_demand, f.recommended_stock, f.confidence,
                        f.forecast_date, f.forecast_reason, f.created_at,
                        i.stock as current_stock
                        FROM (
                        SELECT itemNumber, MAX(forecast_date) as latest_date
                        FROM ai_forecasts
                        WHERE forecast_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
                        GROUP BY itemNumber
                        ) latest
                        JOIN ai_forecasts f ON f.itemNumber = latest.itemNumber AND f.forecast_date = latest.latest_date
                        JOIN item i ON f.itemNumber = i.itemNumber
                        WHERE i.status = 'Active'
                        ORDER BY f.predicted_demand DESC
                        LIMIT 3";

                                $result = $conn->query($highlightSql);

                                if ($result && $result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $confidence = min(100, max(0, round($row['confidence'] * 100)));
                                        $confidenceColor = $confidence > 80 ? 'success' : ($confidence > 60 ? 'warning' : 'danger');
                                        $restockQty = max(0, $row['recommended_stock'] - $row['current_stock']);
                                ?>
                                        <div class="col-md-4 mb-3">
                                            <div class="card h-100 border-<?= $confidenceColor ?>">
                                                <div class="card-header bg-<?= $confidenceColor ?> text-white d-flex justify-content-between">
                                                    <h5 class="mb-0"><?= htmlspecialchars($row['itemName']) ?></h5>
                                                    <span class="badge bg-dark"><?= htmlspecialchars($row['itemNumber']) ?></span>
                                                </div>
                                                <div class="card-body">
                                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                                        <span class="display-5"><?= (int)$row['predicted_demand'] ?></span>
                                                        <span class="badge bg-<?= $confidenceColor ?>">
                                                            <?= $confidence ?>%
                                                        </span>
                                                    </div>
                                                    <div class="alert alert-<?= $confidenceColor ?> py-2 mb-3">
                                                        <i class="fas fa-boxes me-2"></i>
                                                        <strong>Stock:</strong> <?= (int)$row['current_stock'] ?> current
                                                        <br>
                                                        <i class="fas fa-lightbulb me-2"></i>
                                                        <strong>Recommend:</strong> <?= (int)$restockQty ?> more needed
                                                    </div>
                                                    <div class="forecast-meta small">
                                                        <p class="mb-1"><i class="fas fa-calendar-day me-1"></i>
                                                            <?= date('M j, Y', strtotime($row['forecast_date'])) ?>
                                                        </p>
                                                        <p class="mb-1"><i class="fas fa-info-circle me-1"></i>
                                                            <?= htmlspecialchars($row['forecast_reason']) ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                <?php
                                    }
                                } else {
                                    echo '<div class="col-12"><div class="alert alert-warning">No AI forecasts available. <a href="forecast.php" class="alert-link">Generate forecasts now</a>.</div></div>';
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5>Sales & Forecast Accuracy</h5>
                    <div class="btn-group">
                        <button class="btn btn-sm btn-outline-secondary">Last 6 Months</button>
                        <button class="btn btn-sm btn-outline-secondary active">Last 12 Months</button>
                    </div>
                </div>
                <div class="card-body">
                    <canvas id="salesChart" height="300"></canvas>
                </div>
            </div>

            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    // Fetch real sales data
                    fetch('get_sales_data.php')
                        .then(response => response.json())
                        .then(data => {
                            const salesCtx = document.getElementById('salesChart').getContext('2d');
                            const salesChart = new Chart(salesCtx, {
                                type: 'bar',
                                data: {
                                    labels: data.months,
                                    datasets: [{
                                        label: 'Actual Sales',
                                        data: data.sales,
                                        backgroundColor: 'rgba(54, 162, 235, 0.7)',
                                        borderColor: 'rgba(54, 162, 235, 1)',
                                        borderWidth: 1
                                    }, {
                                        label: 'Forecast Accuracy',
                                        data: data.accuracy,
                                        type: 'line',
                                        borderColor: 'rgba(75, 192, 192, 1)',
                                        backgroundColor: 'rgba(75, 192, 192, 0.1)',
                                        borderWidth: 2,
                                        pointBackgroundColor: 'rgba(75, 192, 192, 1)',
                                        yAxisID: 'y1'
                                    }]
                                },
                                options: {
                                    responsive: true,
                                    plugins: {
                                        tooltip: {
                                            mode: 'index',
                                            intersect: false
                                        }
                                    },
                                    scales: {
                                        y: {
                                            beginAtZero: true,
                                            title: {
                                                display: true,
                                                text: 'Sales ($)'
                                            }
                                        },
                                        y1: {
                                            position: 'right',
                                            beginAtZero: true,
                                            max: 100,
                                            title: {
                                                display: true,
                                                text: 'Accuracy (%)'
                                            },
                                            grid: {
                                                drawOnChartArea: false
                                            }
                                        }
                                    }
                                }
                            });
                        })
                        .catch(error => {
                            console.error('Error loading sales data:', error);
                            document.getElementById('salesChart').innerHTML =
                                '<div class="alert alert-warning">Failed to load sales data. Please try again later.</div>';
                        });
                });
            </script>
        </main>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>