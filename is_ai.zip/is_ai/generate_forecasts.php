<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/ai_forecast.php';

$aiForecast = new AIForecast($conn);
$force = isset($_GET['force']) && $_GET['force'] == '1';

try {
    $success = $aiForecast->generateForecasts($force);
    echo json_encode(['success' => $success]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}