<?php
// Enhanced session configuration
ini_set('session.cookie_lifetime', 86400);
ini_set('session.gc_maxlifetime', 86400);
session_start();
require_once 'includes/config.php';

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Initialize login attempts if not set
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
    $_SESSION['last_attempt_time'] = 0;
}

// Check if user is locked out
$current_time = time();
$lockout_duration = 20; // 5 minutes in seconds

if ($_SESSION['login_attempts'] >= 3 && ($current_time - $_SESSION['last_attempt_time']) < $lockout_duration) {
    $remaining_time = $lockout_duration - ($current_time - $_SESSION['last_attempt_time']);
    $minutes = floor($remaining_time / 60);
    $seconds = $remaining_time % 60;
    $error = "Too many failed attempts. Please try again in $minutes minute(s) $seconds second(s).";
} elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (!empty($username) && !empty($password)) {
        // Prepare SQL statement to prevent SQL injection
        $query = "SELECT userID, username, password, fullName FROM user WHERE username = ? AND status = 'Active'";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();

            // Verify password (using MD5 as shown in your database)
            if (md5($password) === $user['password']) {
                // Authentication successful - reset attempts
                $_SESSION['login_attempts'] = 0;
                $_SESSION['last_attempt_time'] = 0;

                $_SESSION['user_id'] = $user['userID'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['full_name'] = $user['fullName'];

                header("Location: index.php");
                exit();
            } else {
                // Increment failed attempts
                $_SESSION['login_attempts']++;
                $_SESSION['last_attempt_time'] = $current_time;
                $error = "Invalid username or password";
            }
        } else {
            // Increment failed attempts
            $_SESSION['login_attempts']++;
            $_SESSION['last_attempt_time'] = $current_time;
            $error = "Invalid username or password";
        }
    } else {
        $error = "Please enter both username and password";
    }
}

// Reset attempts if lockout period has passed
if ($_SESSION['login_attempts'] >= 3 && ($current_time - $_SESSION['last_attempt_time']) >= $lockout_duration) {
    $_SESSION['login_attempts'] = 0;
    $_SESSION['last_attempt_time'] = 0;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Inventory Management System</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --primary-color: #8a63d2;
            --secondary-color: #6c757d;
            --success-color: #00b496;
            --info-color: #17a2b8;
            --warning-color: #ffc107;
            --danger-color: #e74a3b;
            --light-color: #f8f9fc;
            --dark-color: #343a40;
            --sidebar-gradient: linear-gradient(180deg, #403047 10%, #2d0246 100%);
            --navbar-gradient: linear-gradient(90deg, #403047 10%, #2d0246 100%);
            --body-gradient: linear-gradient(180deg, #352245 0%, #1e0230 100%);
            --text-light: rgba(255, 255, 255, 0.85);
            --text-muted: rgba(255, 255, 255, 0.6);
            --card-bg: #2a1a3a;
            --card-border: #3a2a4a;
        }

        body {
            background: var(--body-gradient);
            height: 100vh;
            display: flex;
            align-items: center;
            color: var(--text-light);
            font-family: 'Nunito', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }

        .login-card {
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
            border: none;
            border-radius: 10px;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }

        .login-header {
            background-color: var(--primary-color);
            border-radius: 10px 10px 0 0;
            padding: 1.5rem;
            text-align: center;
        }

        .login-body {
            padding: 2rem;
            background-color: var(--card-bg);
            border-radius: 0 0 10px 10px;
            border: 1px solid var(--card-border);
        }

        .form-control::placeholder {
            color: var(--text-muted);
        }

        .btn-login {
            background-color: var(--primary-color);
            border: none;
            padding: 0.75rem 1rem;
            font-size: 1.1rem;
            font-weight: 600;
            width: 100%;
            transition: all 0.3s;
        }

        .btn-login:hover:not(:disabled) {
            background-color: #7a53c2;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .btn-login:disabled {
            background-color: var(--secondary-color);
            cursor: not-allowed;
            opacity: 0.8;
        }

        .btn-login:hover {
            background-color: #7a53c2;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .attempts-warning {
            color: var(--danger-color);
            font-size: 0.9rem;
            margin-top: 10px;
            text-align: center;
            font-weight: bold;
            font-family: monospace;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="login-card">
            <div class="login-header">
                <h2><i class="fas fa-boxes"></i> Inventory System</h2>
                <p class="mb-0">Sign in to start your session</p>
            </div>
            <div class="login-body">
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form action="login.php" method="POST">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="text" class="form-control" id="username" name="username"
                                value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                                required autofocus>
                        </div>
                    </div>
                    <div class="mb-4">
                        <label for="password" class="form-label">Password</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <?php if ($_SESSION['login_attempts'] > 0): ?>
                            <div class="attempts-warning" id="countdown">
                                <?php if ($_SESSION['login_attempts'] >= 3): ?>
                                    <?php
                                    $remaining = $lockout_duration - ($current_time - $_SESSION['last_attempt_time']);
                                    $mins = floor($remaining / 60);
                                    $secs = $remaining % 60;
                                    ?>
                                    Time remaining: <?php echo "$mins m " . str_pad($secs, 2, '0', STR_PAD_LEFT) . "s"; ?>
                                <?php else: ?>
                                    Attempts remaining: <?php echo (3 - $_SESSION['login_attempts']); ?>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="d-grid mb-3">
                        <button type="submit" class="btn btn-primary btn-login"
                            <?php if (
                                $_SESSION['login_attempts'] >= 3 &&
                                ($current_time - $_SESSION['last_attempt_time']) < $lockout_duration
                            ): ?>
                            disabled
                            <?php endif; ?>>
                            <i class="fas fa-sign-in-alt"></i> Sign In
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Real-time countdown script -->
    <script>
        function updateCountdown() {
            const countdownElement = document.getElementById('countdown');
            const loginButton = document.querySelector('.btn-login');

            if (!countdownElement || !loginButton) return;

            // Get initial values from PHP
            let remaining = <?php echo isset($remaining_time) ? $remaining_time : 0; ?>;

            function tick() {
                const minutes = Math.floor(remaining / 60);
                const seconds = remaining % 60;

                countdownElement.textContent =
                    `Time remaining: ${minutes}m ${seconds.toString().padStart(2, '0')}s`;

                if (remaining <= 0) {
                    countdownElement.textContent = "You may now try again";
                    loginButton.disabled = false;
                    clearInterval(interval);
                }

                remaining--;
            }

            // Only start countdown if locked out
            if (<?php echo ($_SESSION['login_attempts'] >= 3) ? 'true' : 'false'; ?>) {
                tick();
                const interval = setInterval(tick, 1000);
            }
        }

        // Run when page loads
        window.addEventListener('DOMContentLoaded', updateCountdown);
    </script>
</body>

</html>