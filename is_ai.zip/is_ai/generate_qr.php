<?php
require_once 'includes/config.php';
require_once 'includes/qrcode.php';

if(isset($_GET['id'])) {
    $productID = intval($_GET['id']);
    
    // Generate QR code content - URL to mobile edit page
    $url = "http://".$_SERVER['HTTP_HOST']."/edit_item_mobile.php?id=".$productID;
    
    // Output QR code
    QRcode::png($url, false, QR_ECLEVEL_L, 4);
}