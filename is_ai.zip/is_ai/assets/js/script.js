// Initialize charts
if (document.getElementById("salesChart")) {
  const ctx = document.getElementById("salesChart").getContext("2d");
  const salesChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec",
      ],
      datasets: [
        {
          label: "Sales Amount",
          data: [
            12000, 19000, 15000, 20000, 18000, 25000, 22000, 30000, 28000,
            32000, 35000, 40000,
          ],
          backgroundColor: "rgba(78, 115, 223, 0.5)",
          borderColor: "rgba(78, 115, 223, 1)",
          borderWidth: 1,
        },
      ],
    },
    options: {
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false,
        },
        tooltip: {
          callbacks: {
            label: function (context) {
              return "$" + context.raw.toLocaleString();
            },
          },
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            callback: function (value) {
              return "$" + value.toLocaleString();
            },
          },
        },
      },
    },
  });
}
document.addEventListener("DOMContentLoaded", function () {
  // Initialize tooltips
  const tooltipTriggerList = [].slice.call(
    document.querySelectorAll('[data-bs-toggle="tooltip"]')
  );
  tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });
  // Auto-resize textareas
  const textareas = document.querySelectorAll("textarea");
  textareas.forEach((textarea) => {
    textarea.addEventListener("input", function () {
      this.style.height = "auto";
      this.style.height = this.scrollHeight + "px";
    });
  });

  // Sidebar toggle functionality
  const sidebar = document.getElementById("sidebar");
  const sidebarToggle = document.getElementById("sidebarToggle");
  const body = document.body;

  // Toggle sidebar collapse
  function toggleSidebar() {
    body.classList.toggle("sb-sidenav-toggled");
    localStorage.setItem(
      "sb|sidebar-toggle",
      body.classList.contains("sb-sidenav-toggled")
    );
  }

  // Mobile sidebar toggle
  function toggleMobileSidebar() {
    body.classList.toggle("sidebar-show");
  }

  // Check for saved state
  if (localStorage.getItem("sb|sidebar-toggle") === "true") {
    body.classList.add("sb-sidenav-toggled");
  }

  // Desktop toggle button
  document.querySelectorAll(".sidebar-toggler").forEach((button) => {
    button.addEventListener("click", toggleSidebar);
  });

  // Mobile toggle button
  if (sidebarToggle) {
    sidebarToggle.addEventListener("click", toggleMobileSidebar);
  }

  // Close sidebar when clicking outside on mobile
  document.addEventListener("click", function (e) {
    // Mobile close sidebar button
    document.querySelectorAll(".close-sidebar").forEach((button) => {
      button.addEventListener("click", function () {
        document.body.classList.remove("sidebar-show");
      });
    });
  });
});

// Confirm before delete
function confirmAction(message, url) {
  if (confirm(message)) {
    window.location.href = url;
  }
}
