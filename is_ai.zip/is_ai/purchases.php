<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/header.php';

if (isset($_GET['success']) || isset($_GET['error'])) {
    echo '<div class="flash-message-container">';
    if (isset($_GET['success'])) {
        echo '<div class="alert alert-success flash-message">' . htmlspecialchars($_GET['success']) . '</div>';
    }
    if (isset($_GET['error'])) {
        echo '<div class="alert alert-danger flash-message">' . htmlspecialchars($_GET['error']) . '</div>';
    }
    echo '</div>';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Management</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <?php require_once 'includes/sidebar.php'; ?>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2" style="color: white;">Purchase Management</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newPurchaseModal">
                            <i class="bi bi-plus-circle"></i> New Purchase
                        </button>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        <h5 style="color: black;">Recent Purchases</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="purchasesTable">
                                <thead>
                                    <tr>
                                        <th>Purchase ID</th>
                                        <th>Date</th>
                                        <th>Item</th>
                                        <th>Vendor</th>
                                        <th>Quantity</th>
                                        <th>Unit Price</th>
                                        <th>Total</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $query = "SELECT p.*, v.fullName as vendorName, i.itemName 
                                          FROM purchase p
                                          LEFT JOIN vendor v ON p.vendorID = v.vendorID
                                          LEFT JOIN item i ON p.itemNumber = i.itemNumber
                                          ORDER BY p.purchaseDate DESC";
                                    $result = $conn->query($query);

                                    while ($row = $result->fetch_assoc()) {
                                        $total = $row['quantity'] * $row['unitPrice'];
                                        echo "<tr>
                                        <td>{$row['purchaseID']}</td>
                                        <td>" . date('M d, Y', strtotime($row['purchaseDate'])) . "</td>
                                        <td>{$row['itemName']}</td>
                                        <td>{$row['vendorName']}</td>
                                        <td>{$row['quantity']}</td>
                                        <td>$" . number_format($row['unitPrice'], 2) . "</td>
                                        <td>$" . number_format($total, 2) . "</td>
                                        <td>
                                            <button class='btn btn-sm btn-outline-info'>
                                                <i class='bi bi-receipt'></i> Details
                                            </button>
                                        </td>
                                    </tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- New Purchase Modal -->
    <div class="modal fade" id="newPurchaseModal" tabindex="-1" aria-labelledby="newPurchaseModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newPurchaseModalLabel">Record New Purchase</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="process_purchase.php" method="POST">
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="purchaseDate" class="form-label">Purchase Date</label>
                                <input type="date" class="form-control" id="purchaseDate" name="purchaseDate" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label for="vendorID" class="form-label">Vendor</label>
                                <select class="form-select" id="vendorID" name="vendorID" required>
                                    <option value="">Select Vendor</option>
                                    <?php
                                    $query = "SELECT vendorID, fullName FROM vendor WHERE status='Active'";
                                    $result = $conn->query($query);
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<option value='{$row['vendorID']}'>{$row['fullName']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="itemNumber" class="form-label">Item</label>
                                <select class="form-select" id="itemNumber" name="itemNumber" required>
                                    <option value="">Select Item</option>
                                    <?php
                                    $query = "SELECT itemNumber, itemName, unitPrice FROM item WHERE status='Active'";
                                    $result = $conn->query($query);
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<option value='{$row['itemNumber']}' data-price='{$row['unitPrice']}'>{$row['itemName']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="quantity" class="form-label">Quantity</label>
                                <input type="number" class="form-control" id="quantity" name="quantity" min="1" value="1" required>
                            </div>
                            <div class="col-md-3">
                                <label for="unitPrice" class="form-label">Unit Price</label>
                                <input type="number" step="0.01" class="form-control" id="unitPrice" name="unitPrice" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" name="addPurchase">Record Purchase</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize DataTable
            $('#purchasesTable').DataTable({
                responsive: true,
                order: [
                    [1, 'desc']
                ]
            });

            // Auto-fill unit price when item is selected
            $('#itemNumber').change(function() {
                var selectedOption = $(this).find('option:selected');
                var unitPrice = selectedOption.data('price');
                $('#unitPrice').val(unitPrice);
            });

            // Set today's date as default
            document.getElementById('purchaseDate').valueAsDate = new Date();

            // Auto-dismiss alerts after 5 seconds
            setTimeout(function() {
                $('.flash-message').fadeOut('slow');
            }, 5000);
        });
    </script>

    <?php require_once 'includes/footer.php'; ?>