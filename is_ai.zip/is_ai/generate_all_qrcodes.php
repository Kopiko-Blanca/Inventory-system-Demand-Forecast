<?php
require_once 'includes/config.php';
require_once 'includes/qrcode.php';

$result = $conn->query("SELECT productID FROM item");
while($row = $result->fetch_assoc()) {
    $productID = $row['productID'];
    $url = "http://".$_SERVER['HTTP_HOST']."/edit_item_mobile.php?id=".$productID;
    $qrPath = "assets/qrcodes/".$productID.".png";
    
    // Create directory if it doesn't exist
    if (!file_exists('assets/qrcodes')) {
        mkdir('assets/qrcodes', 0777, true);
    }
    
    QRcode::png($url, $qrPath, QR_ECLEVEL_L, 4);
    
    // Update database with QR code path
    $stmt = $conn->prepare("UPDATE item SET qrCode = ? WHERE productID = ?");
    $stmt->bind_param("si", $qrPath, $productID);
    $stmt->execute();
    
    echo "Generated QR code for product ID: $productID<br>";
}

echo "All QR codes generated successfully!";