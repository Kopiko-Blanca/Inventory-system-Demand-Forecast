<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM item WHERE productID = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $item = $stmt->get_result()->fetch_assoc();
    
    if (!$item) die(json_encode(['error' => 'Item not found']));
}

// Add to your existing HTML head section:
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#317EFB"/>
    <title>Edit Inventory</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="manifest" href="manifest.json">
    <script>
        // Register service worker for PWA
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('sw.js')
                    .then(registration => console.log('SW registered'))
                    .catch(err => console.log('SW registration failed'));
            });
        }
        
        // Handle form submission with AJAX
        function updateInventory(e) {
            e.preventDefault();
            
            const formData = {
                productID: document.querySelector('[name="productID"]').value,
                stock: document.querySelector('[name="stock"]').value,
                status: document.querySelector('[name="status"]').value
            };
            
            fetch('api/update_inventory.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            })
            .then(response => response.json())
            .then(data => {
                const alertType = data.error ? 'danger' : 'success';
                showAlert(data.error || data.message, alertType);
                if (!data.error) {
                    // Update displayed stock value
                    document.querySelector('.current-stock').textContent = formData.stock;
                }
            })
            .catch(error => showAlert('Network error', 'danger'));
        }
        
        function showAlert(message, type) {
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
            alertDiv.role = 'alert';
            alertDiv.innerHTML = `
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            `;
            document.querySelector('.alert-container').appendChild(alertDiv);
            
            setTimeout(() => {
                alertDiv.classList.remove('show');
                setTimeout(() => alertDiv.remove(), 150);
            }, 5000);
        }
        
        // Initialize barcode scanner
        function initScanner() {
            if (window.BarcodeDetector) {
                const barcodeDetector = new BarcodeDetector();
                const video = document.createElement('video');
                video.style.display = 'none';
                document.body.appendChild(video);
                
                navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
                    .then(stream => {
                        video.srcObject = stream;
                        video.play();
                        
                        function scanFrame() {
                            barcodeDetector.detect(video)
                                .then(barcodes => {
                                    if (barcodes.length > 0) {
                                        const productID = barcodes[0].rawValue.split('id=')[1];
                                        window.location.href = `edit_item_mobile.php?id=${productID}`;
                                    }
                                    requestAnimationFrame(scanFrame);
                                })
                                .catch(err => {
                                    console.error('Barcode detection error:', err);
                                    setTimeout(scanFrame, 1000);
                                });
                        }
                        scanFrame();
                    })
                    .catch(err => console.error('Camera access error:', err));
            } else {
                console.log('BarcodeDetector not supported');
            }
        }
        
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelector('form').addEventListener('submit', updateInventory);
            
            // Add scan button if on mobile
            if (/Mobi|Android/i.test(navigator.userAgent)) {
                const scanBtn = document.createElement('button');
                scanBtn.className = 'btn btn-success mb-3';
                scanBtn.innerHTML = '<i class="bi bi-upc-scan"></i> Scan Another Product';
                scanBtn.onclick = initScanner;
                document.querySelector('.container').prepend(scanBtn);
            }
        });
    </script>
</head>
<body>
    <div class="container mt-3">
        <div class="alert-container"></div>
        
        <h2>Edit Product: <?= htmlspecialchars($item['itemName']) ?></h2>
        
        <div class="card mb-3">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 text-center">
                        <img src="assets/img/<?= $item['imageURL'] ?>" class="img-thumbnail mb-2" style="max-height: 200px;">
                        <img src="generate_qr.php?id=<?= $item['productID'] ?>" class="img-thumbnail" style="width: 150px;">
                    </div>
                    <div class="col-md-8">
                        <form>
                            <input type="hidden" name="productID" value="<?= $item['productID'] ?>">
                            
                            <div class="mb-3">
                                <label class="form-label">Current Stock</label>
                                <input type="text" class="form-control current-stock" value="<?= $item['stock'] ?>" readonly>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">New Stock</label>
                                <input type="number" class="form-control" name="stock" value="<?= $item['stock'] ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Status</label>
                                <select class="form-select" name="status">
                                    <option value="Active" <?= $item['status'] == 'Active' ? 'selected' : '' ?>>Active</option>
                                    <option value="Disabled" <?= $item['status'] == 'Disabled' ? 'selected' : '' ?>>Disabled</option>
                                </select>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Update Inventory</button>
                            <a href="inventory.php" class="btn btn-secondary">Back to Inventory</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>