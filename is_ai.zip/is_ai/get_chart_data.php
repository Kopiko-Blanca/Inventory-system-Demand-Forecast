<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/ai_forecast.php';

// Set proper headers first
header('Content-Type: application/json');

try {
    $forecastMethod = isset($_GET['method']) ? $_GET['method'] : 'weighted_moving_average';
    $forecastPeriod = isset($_GET['period']) ? (int)$_GET['period'] : 30;
    
    // Initialize AI Forecast if needed
    $aiForecast = ($forecastMethod == 'ai_forecast') ? new AIForecast($conn) : null;

    // 1. Get inventory status summary
    $statusSummary = [
        'sufficient' => 0,
        'needsReorder' => 0,
        'urgentReorder' => 0,
        'insufficientData' => 0
    ];

    // 2. Get trend data for the chart
    $trendData = [
        'labels' => [],
        'datasets' => [
            [
                'label' => 'Historical Sales',
                'data' => [],
                'borderColor' => 'rgba(54, 162, 235, 1)',
                'backgroundColor' => 'rgba(54, 162, 235, 0.1)'
            ],
            [
                'label' => 'Forecasted Demand',
                'data' => [],
                'borderColor' => 'rgba(255, 99, 132, 1)',
                'backgroundColor' => 'rgba(255, 99, 132, 0.1)',
                'borderDash' => [5, 5]
            ]
        ]
    ];

    // Get historical sales data
    $historicalSales = [];
    for ($i = 5; $i >= 0; $i--) {
        $date = date('Y-m', strtotime("-$i months"));
        $trendData['labels'][] = date('M Y', strtotime("-$i months"));
        
        $query = "SELECT SUM(quantity) as total FROM sale 
                 WHERE DATE_FORMAT(saleDate, '%Y-%m') = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $date);
        $stmt->execute();
        $result = $stmt->get_result();
        $sales = $result ? (int)$result->fetch_assoc()['total'] : 0;
        $historicalSales[$date] = $sales;
        $trendData['datasets'][0]['data'][] = $sales;
        $trendData['datasets'][1]['data'][] = null;
    }

    // Get forecast data
    $forecastData = [];
    if ($forecastMethod == 'ai_forecast') {
        // Get AI forecasts for the next 3 months
        $forecastQuery = "SELECT 
            DATE_FORMAT(forecast_date, '%Y-%m') as month,
            AVG(predicted_demand) as forecast
            FROM ai_forecasts
            WHERE forecast_date >= CURDATE()
            GROUP BY DATE_FORMAT(forecast_date, '%Y-%m')
            ORDER BY month ASC
            LIMIT 3";
        
        $forecastResult = $conn->query($forecastQuery);
        while ($row = $forecastResult->fetch_assoc()) {
            $forecastData[$row['month']] = (int)$row['forecast'];
        }
    }

    // Add forecast points
    $lastHistoricalDate = date('Y-m', strtotime("now"));
    $lastHistoricalValue = $historicalSales[$lastHistoricalDate] ?? 0;

    if ($forecastMethod == 'ai_forecast' && !empty($forecastData)) {
        // Connect last historical point to first forecast point
        $trendData['datasets'][1]['data'][5] = $lastHistoricalValue;
        
        // Add forecast months
        foreach ($forecastData as $month => $forecast) {
            $trendData['labels'][] = date('M Y', strtotime($month));
            $trendData['datasets'][1]['data'][] = $forecast;
            $trendData['datasets'][0]['data'][] = null;
        }
    } else {
        // Default forecast (1 month)
        $trendData['labels'][] = date('M Y', strtotime("+1 month"));
        $trendData['datasets'][1]['data'][5] = $lastHistoricalValue;
        $trendData['datasets'][1]['data'][] = $lastHistoricalValue * 1.1;
        $trendData['datasets'][0]['data'][] = null;
    }

    // 3. Analyze inventory status
    $query = "SELECT itemNumber, stock FROM item WHERE status='Active'";
    $result = $conn->query($query);

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $forecastData = ($forecastMethod == 'ai_forecast') 
                ? $aiForecast->getProductForecasts($row['itemNumber'])
                : forecastDemand($row['itemNumber'], $forecastMethod, $forecastPeriod);

            if (empty($forecastData)){
                $statusSummary['insufficientData']++;
                continue;
            }

            $currentStock = (int)$row['stock'];
            $forecastValue = is_numeric($forecastData['forecast']) ? (int)$forecastData['forecast'] : 0;
            $safetyStock = isset($forecastData['safety_stock']) ? (int)$forecastData['safety_stock'] : 0;

            if ($forecastValue === 0 || !isset($forecastData['has_sufficient_data'])) {
                $statusSummary['insufficientData']++;
            } elseif ($currentStock >= ($forecastValue + $safetyStock)) {
                $statusSummary['sufficient']++;
            } else {
                $needed = max(0, $forecastValue - $currentStock);
                $suggestedOrder = max($needed, $safetyStock);

                if ($suggestedOrder > ($currentStock * 0.5)) {
                    $statusSummary['urgentReorder']++;
                } else {
                    $statusSummary['needsReorder']++;
                }
            }
        }
    }

    // Prepare response
    $response = [
        'success' => true,
        'forecastMethod' => $forecastMethod,
        'statusSummary' => $statusSummary,
        'trendData' => $trendData,
        'months' => array_slice($trendData['labels'], 0, 12),
        'sales' => array_slice($trendData['datasets'][0]['data'], 0, 12)
    ];

    echo json_encode($response);
    exit;

} catch (Exception $e) {
    // Log the error
    error_log("Chart data error: " . $e->getMessage());
    
    // Return error response
    echo json_encode([
        'success' => false,
        'error' => 'Failed to load chart data',
        'details' => $e->getMessage()
    ]);
    exit;
}