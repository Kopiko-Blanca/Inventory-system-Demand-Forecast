<?php
header('Content-Type: application/json');
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Verify authentication
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    die(json_encode(['error' => 'Unauthorized']));
}

$input = json_decode(file_get_contents('php://input'), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validate input
        if (empty($input['productID'])) {
            throw new Exception('Product ID is required');
        }
        
        $productID = intval($input['productID']);
        $stock = isset($input['stock']) ? intval($input['stock']) : null;
        $status = $input['status'] ?? null;
        
        // Build update query based on provided fields
        $updates = [];
        $params = [];
        $types = '';
        
        if ($stock !== null) {
            $updates[] = 'stock = ?';
            $params[] = $stock;
            $types .= 'i';
        }
        
        if ($status) {
            $updates[] = 'status = ?';
            $params[] = $status;
            $types .= 's';
        }
        
        if (empty($updates)) {
            throw new Exception('No fields to update');
        }
        
        $params[] = $productID;
        $types .= 'i';
        
        $query = "UPDATE item SET " . implode(', ', $updates) . " WHERE productID = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param($types, ...$params);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Inventory updated']);
        } else {
            throw new Exception('Update failed');
        }
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['error' => $e->getMessage()]);
    }
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}