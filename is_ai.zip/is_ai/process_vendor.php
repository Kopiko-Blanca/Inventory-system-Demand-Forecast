<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['addVendor'])) {
        // Add new vendor
        $fullName = $conn->real_escape_string($_POST['fullName']);
        $email = $conn->real_escape_string($_POST['email']);
        $mobile = $conn->real_escape_string($_POST['mobile']);
        $phone2 = $conn->real_escape_string($_POST['phone2'] ?? '');
        $address = $conn->real_escape_string($_POST['address']);
        $address2 = $conn->real_escape_string($_POST['address2'] ?? '');
        $city = $conn->real_escape_string($_POST['city'] ?? '');
        $district = $conn->real_escape_string($_POST['district']);
        $status = $conn->real_escape_string($_POST['status']);

        $query = "INSERT INTO vendor (fullName, email, mobile, phone2, address, address2, city, district, status) 
                  VALUES ('$fullName', '$email', '$mobile', '$phone2', '$address', '$address2', '$city', '$district', '$status')";
        
        if ($conn->query($query)) {
            header("Location: vendors.php?success=Vendor added successfully");
        } else {
            header("Location: vendors.php?error=Error adding vendor: " . $conn->error);
        }
        exit();
    } elseif (isset($_POST['editVendor'])) {
        // Edit existing vendor
        $vendorID = intval($_POST['vendorID']);
        $fullName = $conn->real_escape_string($_POST['fullName']);
        $email = $conn->real_escape_string($_POST['email']);
        $mobile = $conn->real_escape_string($_POST['mobile']);
        $phone2 = $conn->real_escape_string($_POST['phone2'] ?? '');
        $address = $conn->real_escape_string($_POST['address']);
        $address2 = $conn->real_escape_string($_POST['address2'] ?? '');
        $city = $conn->real_escape_string($_POST['city'] ?? '');
        $district = $conn->real_escape_string($_POST['district']);
        $status = $conn->real_escape_string($_POST['status']);

        $query = "UPDATE vendor SET 
                  fullName = '$fullName',
                  email = '$email',
                  mobile = '$mobile',
                  phone2 = '$phone2',
                  address = '$address',
                  address2 = '$address2',
                  city = '$city',
                  district = '$district',
                  status = '$status'
                  WHERE vendorID = $vendorID";
        
        if ($conn->query($query)) {
            header("Location: vendors.php?success=Vendor updated successfully");
        } else {
            header("Location: vendors.php?error=Error updating vendor: " . $conn->error);
        }
        exit();
    }
} elseif (isset($_GET['delete'])) {
    // Delete vendor
    $vendorID = intval($_GET['delete']);
    $query = "DELETE FROM vendor WHERE vendorID = $vendorID";
    
    if ($conn->query($query)) {
        header("Location: vendors.php?success=Vendor deleted successfully");
    } else {
        header("Location: vendors.php?error=Error deleting vendor: " . $conn->error);
    }
    exit();
}

header("Location: vendors.php");
?>