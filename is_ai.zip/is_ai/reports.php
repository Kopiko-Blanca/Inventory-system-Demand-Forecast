<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/header.php';

// Get date range for reports (default to current month)
$startDate = date('Y-m-01');
$endDate = date('Y-m-t');
?>

<head>
    <link rel="stylesheet" href="assets/css/styles.css"> <!-- Adjust path as needed -->
</head>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'includes/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Reports</h1>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h5>Report Filters</h5>
                </div>
                <div class="card-body">
                    <form class="row g-3" id="reportFilters">
                        <div class="col-md-3">
                            <label for="reportType" class="form-label">Report Type</label>
                            <select class="form-select" id="reportType">
                                <option value="sales">Sales Report</option>
                                <option value="purchases">Purchases Report</option>
                                <option value="inventory">Inventory Report</option>
                                <option value="customers">Customers Report</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="startDate" class="form-label">Start Date</label>
                            <input type="date" class="form-control" id="startDate" value="<?php echo $startDate; ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="endDate" class="form-label">End Date</label>
                            <input type="date" class="form-control" id="endDate" value="<?php echo $endDate; ?>">
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">Generate Report</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h5>Sales Report (<?php echo date('F Y'); ?>)</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover" id="salesReportTable">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Customer</th>
                                    <th>Item</th>
                                    <th>Quantity</th>
                                    <th>Unit Price</th>
                                    <th>Discount</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT s.*, c.fullName as customerName, i.itemName 
                                          FROM sale s
                                          JOIN customer c ON s.customerID = c.customerID
                                          JOIN item i ON s.itemNumber = i.itemNumber
                                          WHERE s.saleDate BETWEEN ? AND ?
                                          ORDER BY s.saleDate DESC";
                                $stmt = $conn->prepare($query);
                                $stmt->bind_param("ss", $startDate, $endDate);
                                $stmt->execute();
                                $result = $stmt->get_result();

                                while ($row = $result->fetch_assoc()) {
                                    $total = $row['quantity'] * $row['unitPrice'] * (1 - $row['discount'] / 100);
                                    echo "<tr>
                                        <td>" . date('M d, Y', strtotime($row['saleDate'])) . "</td>
                                        <td>{$row['customerName']}</td>
                                        <td>{$row['itemName']}</td>
                                        <td>{$row['quantity']}</td>
                                        <td>$" . number_format($row['unitPrice'], 2) . "</td>
                                        <td>{$row['discount']}%</td>
                                        <td>$" . number_format($total, 2) . "</td>
                                    </tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5>Top Selling Items</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="topItemsChart" height="300"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5>Sales by Month</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="monthlySalesChart" height="300"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        $('#salesReportTable').DataTable({
            responsive: true,
            order: [
                [0, 'desc']
            ]
        });

        // Modern compact chart styles
        const chartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        boxWidth: 12,
                        padding: 20,
                        usePointStyle: true
                    }
                },
                tooltip: {
                    enabled: true,
                    intersect: false,
                    mode: 'index',
                    padding: 10,
                    bodySpacing: 8
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        padding: 10
                    }
                },
                y: {
                    grid: {
                        drawBorder: false,
                        color: '#f0f0f0'
                    },
                    ticks: {
                        padding: 10
                    }
                }
            },
            elements: {
                point: {
                    radius: 4,
                    hoverRadius: 6,
                    backgroundColor: '#fff'
                },
                line: {
                    tension: 0.3,
                    borderWidth: 2
                },
                bar: {
                    borderRadius: 4,
                    borderWidth: 0
                }
            }
        };

        // Top Selling Items Chart
        const topItemsCtx = document.getElementById('topItemsChart').getContext('2d');
        const topItemsChart = new Chart(topItemsCtx, {
            type: 'bar',
            data: {
                labels: ['First Bag', 'Travel Bag', 'Sports Bag', 'Office Bag', 'Handbag'],
                datasets: [{
                    label: 'Units Sold',
                    data: [120, 85, 75, 50, 45],
                    backgroundColor: 'rgba(101, 116, 205, 0.8)',
                    hoverBackgroundColor: 'rgba(101, 116, 205, 1)'
                }]
            },
            options: {
                ...chartOptions,
                plugins: {
                    ...chartOptions.plugins,
                    legend: {
                        display: false
                    }
                }
            }
        });

        // Monthly Sales Chart
        const monthlySalesCtx = document.getElementById('monthlySalesChart').getContext('2d');
        const monthlySalesChart = new Chart(monthlySalesCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'Sales ($)',
                    data: [12000, 19000, 15000, 20000, 18000, 25000, 22000, 30000, 28000, 32000, 35000, 40000],
                    backgroundColor: 'rgba(101, 116, 205, 0.1)',
                    borderColor: 'rgba(101, 116, 205, 1)',
                    pointBackgroundColor: '#fff',
                    pointBorderColor: 'rgba(101, 116, 205, 1)',
                    fill: true
                }]
            },
            options: {
                ...chartOptions,
                plugins: {
                    ...chartOptions.plugins,
                    legend: {
                        display: false
                    }
                }
            }
        });

        // Report filter form submission
        document.getElementById('reportFilters').addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Report generation would be implemented here with AJAX');
        });
    });
</script>

<?php require_once 'includes/footer.php'; ?>