<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/header.php';
require_once 'includes/functions.php';
require_once 'includes/ai_forecast.php';

$forecastMethod = isset($_GET['method']) ? $_GET['method'] : 'ai_forecast';
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Initialize AI Forecast
$aiForecast = new AIForecast($conn);

// Generate forecasts if not done in the last 24 hours
$lastGenerated = $conn->query("SELECT IFNULL(MAX(created_at), '2000-01-01') as last FROM ai_forecasts")->fetch_assoc();
if (strtotime($lastGenerated['last']) < strtotime('-24 hours')) {
    $aiForecast->generateForecasts();
}

$forecastPeriod = isset($_GET['period']) ? (int)$_GET['period'] : 30;

$validMethods = ['weighted_moving_average', 'simple_moving_average', 'seasonal_adjusted', 'ai_forecast'];
if (!in_array($forecastMethod, $validMethods)) {
    $forecastMethod = 'weighted_moving_average';
}

if ($forecastPeriod <= 0 || $forecastPeriod > 90) {
    $forecastPeriod = 30;
}

// Get current inventory status counts
$statusCounts = getInventoryStatusSummary();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advanced Demand Forecasting</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <?php require_once 'includes/sidebar.php'; ?>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2" style="color: white">Advanced Demand Forecasting</h1>
                    <div class="btn-group">
                        <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fas fa-download"></i> Export
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#" id="exportCSV">CSV</a></li>
                            <li><a class="dropdown-item" href="#" id="exportPDF">PDF</a></li>
                            <li><a class="dropdown-item" href="#" id="exportExcel">Excel</a></li>
                        </ul>
                        <button type="button" class="btn btn-primary ms-2" id="refreshForecastsBtn">
                            <i class="fas fa-sync me-2"></i>Refresh Forecasts
                        </button>
                    </div>
                </div>

                <!-- Forecasting Method Selector -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Forecasting Parameters</h5>
                    </div>
                    <div class="card-body">
                        <form id="forecastSettings" class="row g-3" method="get">
                            <div class="col-md-4">
                                <label for="forecastMethod" class="form-label">Forecasting Method</label>
                                <select class="form-select" id="forecastMethod" name="method">
                                    <option value="weighted_moving_average" <?= $forecastMethod == 'weighted_moving_average' ? 'selected' : '' ?>>Weighted Moving Average</option>
                                    <option value="simple_moving_average" <?= $forecastMethod == 'simple_moving_average' ? 'selected' : '' ?>>Simple Moving Average</option>
                                    <option value="seasonal_adjusted" <?= $forecastMethod == 'seasonal_adjusted' ? 'selected' : '' ?>>Seasonal Adjusted</option>
                                    <option value="ai_forecast" <?= $forecastMethod == 'ai_forecast' ? 'selected' : '' ?>>AI Forecast</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="forecastPeriod" class="form-label">Forecast Period</label>
                                <select class="form-select" id="forecastPeriod" name="period">
                                    <option value="30" <?= $forecastPeriod == 30 ? 'selected' : '' ?>>30 Days</option>
                                    <option value="60" <?= $forecastPeriod == 60 ? 'selected' : '' ?>>60 Days</option>
                                    <option value="90" <?= $forecastPeriod == 90 ? 'selected' : '' ?>>90 Days</option>
                                </select>
                            </div>
                            <div class="col-md-4 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-sync-alt me-2"></i>Update Forecast
                                </button>
                                <button type="button" class="btn btn-success ms-2" id="generateForecastsBtn">
                                    <i class="fas fa-brain me-2"></i>Generate AI Forecasts
                                </button>
                            </div>
                            <div class="col-md-4">
                                <label for="confidenceThreshold" class="form-label" style="color:black">Minimum Confidence</label>
                                <input type="range" class="form-range" id="confidenceThreshold" name="confidence"
                                    min="0" max="100" step="5" value="<?= MIN_FORECAST_CONFIDENCE * 100 ?>">
                                <div class="d-flex justify-content-between">
                                    <small>0%</small>
                                    <small id="thresholdValue"><?= MIN_FORECAST_CONFIDENCE * 100 ?>%</small>
                                    <small>100%</small>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- AI Forecast Highlights -->
                <?php if ($forecastMethod == 'ai_forecast'): ?>
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="card mb-4" style="background-color: var(--card-bg); border-color: var(--card-border);">
                                <div class="card-header bg-info text-white">
                                    <i class="fas fa-bolt me-2"></i> AI Forecast Highlights
                                    <span class="float-end small">Next <?= $forecastPeriod ?> Days</span>
                                </div>
                                <div class="card-body" style="background-color: var(--card-bg);">
                                    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                                        <?php
                                        $highlightSql = "SELECT i.itemNumber, i.itemName, 
                                    f.predicted_demand, f.recommended_stock, f.confidence,
                                    f.forecast_date, f.forecast_reason, f.created_at,
                                    i.stock as current_stock
                                    FROM (
                                        SELECT itemNumber, MAX(forecast_date) as latest_date
                                        FROM ai_forecasts
                                        WHERE forecast_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)
                                        GROUP BY itemNumber
                                    ) latest
                                    JOIN ai_forecasts f ON f.itemNumber = latest.itemNumber AND f.forecast_date = latest.latest_date
                                    JOIN item i ON f.itemNumber = i.itemNumber
                                    WHERE i.status = 'Active'
                                    ORDER BY f.predicted_demand DESC";

                                        $stmt = $conn->prepare($highlightSql);
                                        $stmt->bind_param("i", $forecastPeriod);
                                        $stmt->execute();
                                        $result = $stmt->get_result();

                                        if ($result && $result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $confidence = min(100, max(0, round($row['confidence'] * 100)));
                                                $confidenceColor = $confidence > 80 ? 'success' : ($confidence > 60 ? 'warning' : 'danger');
                                                $restockQty = max(0, $row['recommended_stock'] - $row['current_stock']);
                                        ?>
                                                <div class="col">
                                                    <div class="card h-100 border-<?= $confidenceColor ?>" style="background-color: var(--card-bg);">
                                                        <div class="card-header bg-<?= $confidenceColor ?> text-white d-flex justify-content-between">
                                                            <h5 class="mb-0"><?= htmlspecialchars($row['itemName']) ?></h5>
                                                            <span class="badge bg-dark"><?= htmlspecialchars($row['itemNumber']) ?></span>
                                                        </div>
                                                        <div class="card-body text-light"> <!-- Added text-light here -->
                                                            <div class="d-flex justify-content-between align-items-center mb-3">
                                                                <span class="display-5"><?= (int)$row['predicted_demand'] ?></span>
                                                                <span class="badge bg-<?= $confidenceColor ?>">
                                                                    <?= $confidence ?>%
                                                                </span>
                                                            </div>
                                                            <div class="alert alert-<?= $confidenceColor ?> py-2 mb-3 text-dark"> <!-- Force dark text -->
                                                                <i class="fas fa-boxes me-2"></i>
                                                                <strong>Stock:</strong> <?= (int)$row['current_stock'] ?> current
                                                                <br>
                                                                <i class="fas fa-lightbulb me-2"></i>
                                                                <strong>Recommend:</strong> <?= (int)$restockQty ?> more needed
                                                            </div>
                                                            <div class="forecast-meta small text-light"> <!-- Added text-light -->
                                                                <p class="mb-1"><i class="fas fa-calendar-day me-1"></i>
                                                                    <?= date('M j, Y', strtotime($row['forecast_date'])) ?>
                                                                </p>
                                                                <p class="mb-1"><i class="fas fa-info-circle me-1"></i>
                                                                    <?= htmlspecialchars($row['forecast_reason']) ?>
                                                                </p>
                                                                <p class="mb-0"><i class="fas fa-history me-1"></i>
                                                                    <?= date('M j, Y H:i', strtotime($row['created_at'])) ?>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                        <?php
                                            }
                                        } else {
                                            echo '<div class="col-12"><div class="alert alert-warning text-dark">No AI forecasts available. <a href="#" class="alert-link" id="generateForecastsLink">Generate forecasts now</a>.</div></div>';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Forecast Results -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Product Demand Forecast</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="forecastTable">
                                <thead>
                                    <tr>
                                        <th>Product ID</th>
                                        <th>Product Name</th>
                                        <th>Current Stock</th>
                                        <th>Forecasted Demand</th>
                                        <th>Confidence</th>
                                        <th>Method</th>
                                        <th>Safety Stock</th>
                                        <th>Suggested Order</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $query = "SELECT productID, itemNumber, itemName, stock FROM item WHERE status='Active'";
                                    $result = $conn->query($query);

                                    while ($row = $result->fetch_assoc()) {
                                        if ($forecastMethod == 'ai_forecast') {
                                            $aiForecastData = $aiForecast->getProductForecasts($row['itemNumber']);
                                            $latestForecast = !empty($aiForecastData) ? $aiForecastData[0] : null;

                                            if ($latestForecast) {
                                                $forecastValue = (int)$latestForecast['predicted_demand'];
                                                $confidenceValue = $latestForecast['confidence'];
                                                $safetyStock = isset($latestForecast['recommended_stock']) ?
                                                    max(0, $latestForecast['recommended_stock'] - $latestForecast['predicted_demand']) :
                                                    round($latestForecast['predicted_demand'] * 0.2);

                                                $forecastData = [
                                                    'forecast' => $forecastValue,
                                                    'confidence' => $confidenceValue,
                                                    'safety_stock' => $safetyStock,
                                                    'method' => 'AI Forecast',
                                                    'has_sufficient_data' => true,
                                                    'is_valid' => true
                                                ];
                                            } else {
                                                $forecastData = [
                                                    'forecast' => "No AI forecast",
                                                    'confidence' => 0,
                                                    'safety_stock' => 0,
                                                    'method' => 'N/A',
                                                    'has_sufficient_data' => false,
                                                    'is_valid' => false
                                                ];
                                            }
                                        } else {
                                            $forecastData = forecastDemand($row['itemNumber'], $forecastMethod, $forecastPeriod);
                                        }

                                        $currentStock = max(0, (int)$row['stock']);

                                        // Initialize all variables with defaults
                                        $forecastValue = $forecastData['forecast'] ?? "Not enough data";
                                        $safetyStock = $forecastData['safety_stock'] ?? 0;
                                        $suggestedOrder = 0;
                                        $status = '<span class="badge bg-secondary">Insufficient Data</span>';
                                        $showSuggestedOrder = false;

                                        // Only proceed if we have sufficient data
                                        if (!empty($forecastData['has_sufficient_data']) && $forecastData['has_sufficient_data']) {
                                            $forecastValue = is_numeric($forecastValue) ? (int)$forecastValue : 0;
                                            $safetyStock = isset($forecastData['safety_stock']) ? (int)$forecastData['safety_stock'] : 0;

                                            // Calculate suggested order if forecast is valid
                                            if (!empty($forecastData['is_valid']) && $forecastData['is_valid']) {
                                                $needed = max(0, $forecastValue - $currentStock);
                                                $suggestedOrder = max($needed, $safetyStock);
                                                $showSuggestedOrder = true;

                                                // Don't suggest orders for items with sufficient stock + safety buffer
                                                if ($currentStock >= ($forecastValue + $safetyStock)) {
                                                    $suggestedOrder = 0;
                                                }

                                                // Determine status
                                                if ($suggestedOrder > ($currentStock * 0.5)) {
                                                    $status = '<span class="badge bg-danger">Urgent Reorder</span>';
                                                } elseif ($suggestedOrder > 0) {
                                                    $status = '<span class="badge bg-warning">Reorder</span>';
                                                } else {
                                                    $status = '<span class="badge bg-success">OK</span>';
                                                }
                                            } else {
                                                $status = '<span class="badge bg-info">Low Confidence</span>';
                                                $forecastValue = "Low Confidence";
                                            }
                                        }

                                        // Confidence indicator
                                        $confidenceValue = isset($forecastData['confidence']) ? $forecastData['confidence'] : 0;
                                        $confidenceColor = $confidenceValue > 0.8 ? 'success' : ($confidenceValue > 0.6 ? 'warning' : 'danger');
                                        $confidenceBadge = '<span class="badge bg-' . $confidenceColor . '">' .
                                            number_format($confidenceValue * 100, 0) . '%</span>';

                                        echo "<tr>
                                                <td>{$row['itemNumber']}</td>
                                                <td>{$row['itemName']}</td>
                                                <td>{$currentStock}</td>
                                                <td>{$forecastValue}</td>
                                                <td>{$confidenceBadge}</td>
                                                <td>{$forecastData['method']}</td>
                                                <td>{$safetyStock}</td>
                                                <td>" . ($showSuggestedOrder ? $suggestedOrder : "N/A") . "</td>
                                                <td>{$status}</td>
                                                <td>
                                                    <button class='btn btn-sm btn-outline-primary view-trend' data-id='{$row['itemNumber']}'>
                                                        <i class='fas fa-chart-line'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-outline-success reorder-btn' 
                                                            data-id='{$row['itemNumber']}' 
                                                            data-qty='" . ($showSuggestedOrder ? $suggestedOrder : 0) . "'
                                                            data-name='{$row['itemName']}'
                                                            data-price='" . getItemPrice($row['itemNumber']) . "'>
                                                        <i class='fas fa-cart-plus'></i> Reorder
                                                    </button>
                                                </td>
                                            </tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Interactive Charts Section -->
                <div class="row">
                    <div class="col-md-8 mb-4">
                        <div class="card h-100">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0">Demand Forecast Trend Analysis</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="forecastTrendChart" height="300"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100">
                            <div class="card-header bg-info text-white">
                                <h5 class="mb-0">Inventory Status Summary</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="inventoryStatusChart" height="300"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0">Sales & Forecast Accuracy</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="salesChart" height="300"></canvas>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Modal for detailed product forecast -->
    <div class="modal fade" id="forecastDetailModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class=" modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Detailed Forecast Analysis</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Historical Sales Data</h6>
                            <div class="table-responsive">
                                <table class="table table-sm" id="historicalDataTable">
                                <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Quantity</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <h6>Forecast Details</h6>
                            <div class="mb-3">
                                <canvas id="modalForecastChart" height="200"></canvas>
                            </div>
                            <div class="alert alert-info">
                                <strong>Forecast Method:</strong> <span id="modalMethod"></span><br>
                                <strong>Confidence Level:</strong> <span id="modalConfidence"></span><br>
                                <strong>Safety Stock:</strong> <span id="modalSafetyStock"></span><br>
                                <strong>Trend Factor:</strong> <span id="modalTrend"></span>
                                <div id="aiForecastReason" class="mt-2"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="generatePurchaseOrder">
                        <i class="fas fa-file-invoice-dollar me-2"></i>Generate Purchase Order
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Define consistent chart options
        const chartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        boxWidth: 12,
                        padding: 20,
                        usePointStyle: true
                    }
                },
                tooltip: {
                    enabled: true,
                    intersect: false,
                    mode: 'index',
                    padding: 10,
                    bodySpacing: 8
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        padding: 10
                    }
                },
                y: {
                    grid: {
                        drawBorder: false,
                        color: '#f0f0f0'
                    },
                    ticks: {
                        padding: 10
                    }
                }
            },
            elements: {
                point: {
                    radius: 4,
                    hoverRadius: 6,
                    backgroundColor: '#fff'
                },
                line: {
                    tension: 0.3,
                    borderWidth: 2
                },
                bar: {
                    borderRadius: 4,
                    borderWidth: 0
                }
            }
        };

        document.addEventListener('DOMContentLoaded', function() {
            // Initialize all charts
            const salesCtx = document.getElementById('salesChart').getContext('2d');
            const statusCtx = document.getElementById('inventoryStatusChart').getContext('2d');
            const trendCtx = document.getElementById('forecastTrendChart').getContext('2d');

            // 1. Sales Chart
            fetch('get_chart_data.php?method=<?= $forecastMethod ?>')
                .then(response => {
                    if (!response.ok) throw new Error('Network response was not ok');
                    return response.json();
                })
                .then(data => {
                    if (data.error) {
                        console.error('Error:', data.error);
                        document.getElementById('salesChart').innerHTML =
                            '<div class="alert alert-danger">Error loading chart data: ' + data.error + '</div>';
                        return;
                    }

                    new Chart(salesCtx, {
                        type: 'bar',
                        data: {
                            labels: data.months,
                            datasets: [{
                                label: 'Actual Sales ($)',
                                data: data.sales,
                                backgroundColor: 'rgba(101, 116, 205, 0.8)',
                                hoverBackgroundColor: 'rgba(101, 116, 205, 1)'
                            }, {
                                label: 'Forecast Accuracy (%)',
                                data: data.accuracy,
                                type: 'line',
                                borderColor: 'rgba(0, 180, 150, 1)',
                                backgroundColor: 'rgba(0, 180, 150, 0.1)',
                                borderWidth: 2,
                                pointBackgroundColor: '#fff'
                            }]
                        },
                        options: chartOptions
                    });
                })
                .catch(error => {
                    console.error('Error loading sales data:', error);
                    document.getElementById('salesChart').innerHTML =
                        '<div class="alert alert-danger">Failed to load sales data. Please try again later.</div>';
                });

            // 2. Inventory Status Chart - Using real data from PHP
            const statusCounts = <?php echo json_encode($statusCounts); ?>;
            const statusChart = new Chart(statusCtx, {
                type: 'bar',
                data: {
                    labels: ['Inventory Status'],
                    datasets: [{
                            label: 'Sufficient Stock',
                            data: [statusCounts[0]],
                            backgroundColor: 'rgba(0, 180, 150, 0.8)'
                        },
                        {
                            label: 'Needs Reorder',
                            data: [statusCounts[1]],
                            backgroundColor: 'rgba(255, 193, 7, 0.8)'
                        },
                        {
                            label: 'Urgent Reorder',
                            data: [statusCounts[2]],
                            backgroundColor: 'rgba(231, 74, 59, 0.8)'
                        },
                        {
                            label: 'Insufficient Data',
                            data: [statusCounts[3]],
                            backgroundColor: 'rgba(108, 117, 125, 0.8)'
                        }
                    ]
                },
                options: chartOptions
            });

            // 3. Trend Chart
            const trendChart = new Chart(trendCtx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                            label: 'Historical Sales',
                            data: [],
                            borderColor: 'rgba(101, 116, 205, 1)',
                            backgroundColor: 'rgba(101, 116, 205, 0.1)',
                            borderWidth: 2,
                            fill: true
                        },
                        {
                            label: 'Forecasted Demand',
                            data: [],
                            borderColor: 'rgba(138, 99, 210, 1)',
                            backgroundColor: 'rgba(138, 99, 210, 0.1)',
                            borderWidth: 2,
                            borderDash: [5, 5],
                            fill: false
                        }
                    ]
                },
                options: chartOptions
            });

            // View trend button handler
            document.querySelectorAll('.view-trend').forEach(button => {
                button.addEventListener('click', function() {
                    const productId = this.getAttribute('data-id');
                    const productName = this.closest('tr').querySelector('td:nth-child(2)').textContent;

                    // Show loading state
                    trendChart.options.plugins.title.text = 'Loading data for ' + productName + '...';
                    trendChart.update();

                    fetch('get_product_forecast.php?item=' + productId)
                        .then(response => response.json())
                        .then(data => {
                            if (data.error) {
                                alert('Error: ' + data.error);
                                return;
                            }

                            // Format dates for better display
                            const formatDate = (dateStr) => {
                                const date = new Date(dateStr);
                                return date.toLocaleDateString('en-US', {
                                    month: 'short',
                                    day: 'numeric'
                                });
                            };

                            // Prepare historical data
                            const historicalDates = data.historical.map(item => formatDate(item.date));
                            const historicalValues = data.historical.map(item => item.quantity);

                            // Prepare forecast data (align with last historical point)
                            const forecastDates = [...historicalDates.slice(-1)];
                            const forecastValues = [...historicalValues.slice(-1)];

                            if (data.forecast && data.forecast.length > 0) {
                                // Add forecast points (assuming 30-day forecast)
                                const forecastLength = Math.min(30, data.forecast.length);
                                for (let i = 0; i < forecastLength; i++) {
                                    const forecastDate = new Date();
                                    forecastDate.setDate(forecastDate.getDate() + i + 1);
                                    forecastDates.push(formatDate(forecastDate));
                                    forecastValues.push(data.forecast[i]);
                                }
                            }

                            // Update chart data
                            trendChart.data.labels = [...historicalDates, ...forecastDates.slice(1)];
                            trendChart.data.datasets[0].data = historicalValues;
                            trendChart.data.datasets[1].data = forecastValues;

                            // Update chart options
                            trendChart.options.plugins.title.text = 'Demand Forecast for ' + productName;
                            trendChart.update();
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            trendChart.options.plugins.title.text = 'Error loading data for ' + productName;
                            trendChart.update();
                            alert('Failed to load forecast data');
                        });
                });
            });

            // Refresh forecasts button
            document.getElementById('refreshForecastsBtn').addEventListener('click', function() {
                fetch('generate_forecasts.php?force=1')
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('Forecasts refreshed successfully!');
                            window.location.reload();
                        } else {
                            alert('Error: ' + (data.error || 'Failed to refresh forecasts'));
                        }
                    });
            });

            // Generate AI Forecasts button
            document.getElementById('generateForecastsBtn').addEventListener('click', function() {
                if (confirm('Generate AI forecasts for all products? This may take a few minutes.')) {
                    fetch('generate_forecasts.php')
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                alert('AI forecasts generated successfully!');
                                window.location.reload();
                            } else {
                                alert('Error: ' + (data.error || 'Failed to generate forecasts'));
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            alert('Error generating forecasts');
                        });
                }
            });

            // Reorder button handler
            document.querySelectorAll('.reorder-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const productId = this.getAttribute('data-id');
                    const productName = this.getAttribute('data-name');
                    const suggestedQty = parseInt(this.getAttribute('data-qty'));
                    const unitPrice = parseFloat(this.getAttribute('data-price'));

                    if (isNaN(suggestedQty) || suggestedQty <= 0) {
                        alert('No reorder needed for ' + productName);
                        return;
                    }

                    // Confirm with user
                    if (!confirm(`Create purchase order for ${suggestedQty} units of ${productName} at $${unitPrice.toFixed(2)} each?`)) {
                        return;
                    }

                    // Create and submit form
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = 'process_purchase.php';

                    // Add CSRF token if you have one
                    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;
                    if (csrfToken) {
                        const csrfInput = document.createElement('input');
                        csrfInput.type = 'hidden';
                        csrfInput.name = 'csrf_token';
                        csrfInput.value = csrfToken;
                        form.appendChild(csrfInput);
                    }

                    // Add purchase data
                    const fields = {
                        'itemNumber': productId,
                        'itemName': productName,
                        'quantity': suggestedQty,
                        'unitPrice': unitPrice,
                        'vendorID': '<?php echo getPreferredVendor($row["itemNumber"] ?? ""); ?>',
                        'addPurchase': '1'
                    };

                    for (const [name, value] of Object.entries(fields)) {
                        const input = document.createElement('input');
                        input.type = 'hidden';
                        input.name = name;
                        input.value = value;
                        form.appendChild(input);
                    }

                    document.body.appendChild(form);
                    form.submit();
                });
            });

            // Confidence threshold slider
            const thresholdSlider = document.getElementById('confidenceThreshold');
            const thresholdValue = document.getElementById('thresholdValue');
            thresholdSlider.addEventListener('input', function() {
                thresholdValue.textContent = this.value + '%';
            });

            // Highlight urgent items in forecast table
            document.querySelectorAll('#forecastTable tr').forEach(row => {
                const statusCell = row.querySelector('td:nth-child(9)');
                if (statusCell && statusCell.textContent.includes('Urgent')) {
                    row.classList.add('table-danger');
                    row.style.borderLeft = '4px solid #dc3545';
                }
            });

            // Format currency values in purchases table
            document.querySelectorAll('#purchasesTable td:nth-child(6), #purchasesTable td:nth-child(7)').forEach(cell => {
                if (cell.textContent.includes('$')) {
                    cell.classList.add('currency');
                }
            });
        });
    </script>
    <?php require_once 'includes/footer.php'; ?>
</body>

</html>