<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/header.php';
if (isset($_GET['success']) || isset($_GET['error'])) {
    echo '<div class="flash-message-container">';
    if (isset($_GET['success'])) {
        echo '<div class="alert alert-success flash-message ">' . htmlspecialchars($_GET['success']) . '</div>';
    }
    if (isset($_GET['error'])) {
        echo '<div class="alert alert-danger flash-message">' . htmlspecialchars($_GET['error']) . '</div>';
    }
    echo '</div>';
}
?>

<head>
    <link rel="stylesheet" href="assets/css/styles.css"> <!-- Adjust path as needed -->
</head>

<div class="container-fluid">
    <div class="row">
        <?php require_once 'includes/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Customer Management</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newCustomerModal">
                        <i class="bi bi-plus-circle"></i> New Customer
                    </button>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h5>Customer List</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover" id="customersTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Address</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
</thead>
                            <tbody>
                                <?php
                                $query = "SELECT * FROM customer ORDER BY customerID DESC";
                                $result = $conn->query($query);

                                while ($row = $result->fetch_assoc()) {
                                    $statusBadge = ($row['status'] == 'Active') ?
                                        '<span class="badge bg-success">Active</span>' :
                                        '<span class="badge bg-secondary">Disabled</span>';

                                    echo "<tr>
                                        <td>{$row['customerID']}</td>
                                        <td>{$row['fullName']}</td>
                                        <td>{$row['email']}</td>
                                        <td>{$row['mobile']}</td>
                                        <td>{$row['address']}, {$row['city']}</td>
                                        <td>{$statusBadge}</td>
                                        <td>
                                            <button class='btn btn-sm btn-outline-primary' data-bs-toggle='modal' data-bs-target='#editCustomerModal' data-id='{$row['customerID']}'>
                                                <i class='bi bi-pencil'></i>
                                            </button>
                                            <button class='btn btn-sm btn-outline-danger' onclick='confirmDelete({$row['customerID']}, \"customer\")'>
                                                <i class='bi bi-trash'></i>
                                            </button>
                                        </td>
                                    </tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- New Customer Modal -->
<div class="modal fade" id="newCustomerModal" tabindex="-1" aria-labelledby="newCustomerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content bg-light">
            <div class="modal-header">
                <h5 class="modal-title" id="newCustomerModalLabel">Add New Customer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="process_customer.php" method="POST">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="fullName" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="fullName" name="fullName" required>
                        </div>
                        <div class="col-md-6">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>
                        <div class="col-md-6">
                            <label for="mobile" class="form-label">Mobile</label>
                            <input type="text" class="form-control" id="mobile" name="mobile" required>
                        </div>
                        <div class="col-md-6">
                            <label for="phone2" class="form-label">Secondary Phone</label>
                            <input type="text" class="form-control" id="phone2" name="phone2">
                        </div>
                        <div class="col-md-6">
                            <label for="address" class="form-label">Address</label>
                            <input type="text" class="form-control" id="address" name="address" required>
                        </div>
                        <div class="col-md-6">
                            <label for="address2" class="form-label">Address 2</label>
                            <input type="text" class="form-control" id="address2" name="address2">
                        </div>
                        <div class="col-md-4">
                            <label for="city" class="form-label">City</label>
                            <input type="text" class="form-control" id="city" name="city">
                        </div>
                        <div class="col-md-4">
                            <label for="district" class="form-label">District</label>
                            <input type="text" class="form-control" id="district" name="district" required>
                        </div>
                        <div class="col-md-4">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select" id="status" name="status">
                                <option value="Active">Active</option>
                                <option value="Disabled">Disabled</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" name="addCustomer">Save Customer</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Edit Customer Modal -->
<div class="modal fade" id="editCustomerModal" tabindex="-1" aria-labelledby="editCustomerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content bg-light">
            <div class="modal-header">
                <h5 class="modal-title" id="editCustomerModalLabel">Edit Customer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="process_customer.php" method="POST">
                <input type="hidden" id="edit_customerID" name="customerID">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="edit_fullName" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="edit_fullName" name="fullName" required>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="edit_email" name="email">
                        </div>
                        <div class="col-md-6">
                            <label for="edit_mobile" class="form-label">Mobile</label>
                            <input type="text" class="form-control" id="edit_mobile" name="mobile" required>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_phone2" class="form-label">Secondary Phone</label>
                            <input type="text" class="form-control" id="edit_phone2" name="phone2">
                        </div>
                        <div class="col-md-6">
                            <label for="edit_address" class="form-label">Address</label>
                            <input type="text" class="form-control" id="edit_address" name="address" required>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_address2" class="form-label">Address 2</label>
                            <input type="text" class="form-control" id="edit_address2" name="address2">
                        </div>
                        <div class="col-md-4">
                            <label for="edit_city" class="form-label">City</label>
                            <input type="text" class="form-control" id="edit_city" name="city">
                        </div>
                        <div class="col-md-4">
                            <label for="edit_district" class="form-label">District</label>
                            <input type="text" class="form-control" id="edit_district" name="district" required>
                        </div>
                        <div class="col-md-4">
                            <label for="edit_status" class="form-label">Status</label>
                            <select class="form-select" id="edit_status" name="status">
                                <option value="Active">Active</option>
                                <option value="Disabled">Disabled</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" name="editCustomer">Update Customer</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        $('#customersTable').DataTable({
            responsive: true
        });

        // Edit Customer Modal Handler
        $('#editCustomerModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var id = button.data('id');
            
            // Fetch customer data via AJAX
            $.ajax({
                url: 'fetch_customer.php',
                type: 'GET',
                data: {id: id},
                dataType: 'json',
                success: function(data) {
                    $('#edit_customerID').val(data.customerID);
                    $('#edit_fullName').val(data.fullName);
                    $('#edit_email').val(data.email);
                    $('#edit_mobile').val(data.mobile);
                    $('#edit_phone2').val(data.phone2);
                    $('#edit_address').val(data.address);
                    $('#edit_address2').val(data.address2);
                    $('#edit_city').val(data.city);
                    $('#edit_district').val(data.district);
                    $('#edit_status').val(data.status);
                }
            });
        });

        // Delete Confirmation Function
        window.confirmDelete = function(id, type) {
            if (confirm('Are you sure you want to delete this ' + type + '?')) {
                window.location.href = 'process_' + type + '.php?delete=' + id;
            }
        }
    });
</script>

<?php require_once 'includes/footer.php'; ?>