<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['addPurchase'])) {
    // Get form data
    $purchaseDate = $conn->real_escape_string($_POST['purchaseDate']);
    $vendorID = (int)$_POST['vendorID'];
    $itemNumber = $conn->real_escape_string($_POST['itemNumber']);
    $quantity = (int)$_POST['quantity'];
    $unitPrice = (float)$_POST['unitPrice'];
    
    try {
        // Start transaction
        $conn->begin_transaction();
        
        // 1. Get item name and vendor name
        $itemQuery = $conn->query("SELECT itemName FROM item WHERE itemNumber = '$itemNumber'");
        $vendorQuery = $conn->query("SELECT fullName FROM vendor WHERE vendorID = $vendorID");
        
        if ($itemQuery->num_rows === 0 || $vendorQuery->num_rows === 0) {
            throw new Exception("Invalid item or vendor selected");
        }
        
        $itemName = $itemQuery->fetch_assoc()['itemName'];
        $vendorName = $vendorQuery->fetch_assoc()['fullName'];
        
        // 2. Insert purchase record
        $insertQuery = "INSERT INTO purchase (itemNumber, purchaseDate, itemName, unitPrice, quantity, vendorName, vendorID) 
                       VALUES ('$itemNumber', '$purchaseDate', '$itemName', $unitPrice, $quantity, '$vendorName', $vendorID)";
        
        if (!$conn->query($insertQuery)) {
            throw new Exception("Failed to record purchase: " . $conn->error);
        }
        
        // 3. Update inventory stock
        $updateQuery = "UPDATE item SET stock = stock + $quantity WHERE itemNumber = '$itemNumber'";
        
        if (!$conn->query($updateQuery)) {
            throw new Exception("Failed to update inventory: " . $conn->error);
        }
        
        // Commit transaction
        $conn->commit();
        
        // Redirect with success message
        header("Location: purchases.php?success=Purchase+recorded+successfully+and+inventory+updated");
        exit();
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        header("Location: purchases.php?error=" . urlencode($e->getMessage()));
        exit();
    }
} else {
    header("Location: purchases.php");
    exit();
}