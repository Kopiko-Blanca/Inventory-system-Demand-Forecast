<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/ai_forecast.php';

header('Content-Type: application/json');

try {
    if (!isset($_GET['item'])) {
        throw new Exception('Item number not provided');
    }

    $itemNumber = $_GET['item'];
    $aiForecast = new AIForecast($conn);
    
    // Get historical data (last 90 days)
    $historical = [];
    $historyQuery = "SELECT saleDate as date, SUM(quantity) as quantity 
                    FROM sale 
                    WHERE itemNumber = ? 
                    AND saleDate >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
                    GROUP BY saleDate
                    ORDER BY saleDate ASC";
    $stmt = $conn->prepare($historyQuery);
    $stmt->bind_param("s", $itemNumber);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $historical[] = $row;
    }
    
    // Get forecast data (next 30 days)
    $forecastData = $aiForecast->getProductForecasts($itemNumber);
    $forecast = [];
    
    // Only take the next 30 days of forecast
    $forecastDays = min(30, count($forecastData));
    for ($i = 0; $i < $forecastDays; $i++) {
        $forecast[] = $forecastData[$i]['predicted_demand'];
    }
    
    // Get product info
    $productQuery = "SELECT itemName FROM item WHERE itemNumber = ?";
    $stmt = $conn->prepare($productQuery);
    $stmt->bind_param("s", $itemNumber);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    
    // Calculate trend
    $trend = $aiForecast->calculateTrendFactor($historical);
    
    echo json_encode([
        'success' => true,
        'productName' => $product['itemName'],
        'historical' => $historical,
        'forecast' => $forecast,
        'method' => 'AI Forecast',
        'confidence' => $forecastData[0]['confidence'] ?? 0,
        'safety_stock' => ($forecastData[0]['recommended_stock'] ?? 0) - ($forecastData[0]['predicted_demand'] ?? 0),
        'trend' => $trend
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}